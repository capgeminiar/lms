package com.cg.author.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.author.bean.Author;


@Repository
@Transactional
public class AuthorDao implements IAuthorDao
{
	@PersistenceContext
	EntityManager em;
	@Override
	public Author addAuthor(Author author)
	{
			System.out.println("before persist");
			try {
			em.persist(author);
			}
			catch(Exception e) {System.out.println("problem in persisting");}
			System.out.println("after persist");
			em.flush();

		return author;
	}
	@Override
	public Author searchAuthor(Author author) 
	{	
		System.out.println("Author ID:"+author.getAuthorid());
		Author auth=em.find(Author.class, author.getAuthorid());
		System.out.println("Author"+auth);
		System.out.println("In dao for search");
		return auth ;
	}
	@Override
	public Author updateAuth(Author author) 
	{
		Author auth=em.merge(author);
		em.flush();
		return auth;
	}
	@Override
	public int removeAuthor(Author auth)
	{
		em.remove(auth);
		em.flush();
				return 0;
	}

}
