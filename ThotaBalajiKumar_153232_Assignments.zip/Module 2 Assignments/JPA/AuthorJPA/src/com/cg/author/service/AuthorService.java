package com.cg.author.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.author.bean.Author;
import com.cg.author.dao.IAuthorDao;


@Service
@Transactional
public class AuthorService implements IAuthorService
{
	@Autowired
	IAuthorDao dao;

	@Override
	public Author addAuthor(Author author) 
	{
	
		return dao.addAuthor(author);
	}

	@Override
	public Author searchAuthor(Author author)
	{
		
		return dao.searchAuthor(author);
	}

	@Override
	public Author updateAuth(Author author) {
		
		return dao.updateAuth(author);
	}

	@Override
	public int removeAuthor(Author auth)
	{
	 return	dao.removeAuthor(auth);
	}

}
