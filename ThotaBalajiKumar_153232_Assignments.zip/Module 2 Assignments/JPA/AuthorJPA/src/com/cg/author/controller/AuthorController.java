package com.cg.author.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.author.bean.Author;
import com.cg.author.service.IAuthorService;

@Controller
public class AuthorController
{
	@Autowired
	IAuthorService service;
	
	@RequestMapping("/index")
	public ModelAndView index()
	{
		return new ModelAndView("index");
		
		
	}
	
	@RequestMapping("/addauthor")
	public ModelAndView addAuthor()
	{
		Author author=new Author();
		
		return new  ModelAndView("addauthorform","author",author);
		
	}
	
	@RequestMapping("/authoraddition")
	public ModelAndView authoraddition(@ModelAttribute ("author") @Validated Author author,BindingResult result )
	{	
		System.out.println("in auth addition");
		ModelAndView mv=null;
		Author auth=service.addAuthor(author);
		System.out.println("back from dao");
		if(auth!=null)
		{
		mv=new ModelAndView("addSuccess");
		}
		else
		{
			mv=new ModelAndView("error");
		}
		
		return mv;
		
	}
	
	@RequestMapping("/retrieveauthor")
	public ModelAndView retrieveAuthor()
	{	
		ModelAndView mv=null;
		Author author=new Author();
		 mv=new ModelAndView("retrieveauthorform","author",author);
		 mv.addObject("isFirst",true);
		 return mv;
	}
	
	@RequestMapping("/authorsearch")
	public ModelAndView authorsearch(@ModelAttribute ("author") @Validated Author author,BindingResult result)
	{	
		ModelAndView mv=null;
		System.out.println("in controller authorsearch");
		Author auth=service.searchAuthor(author);
		System.out.println("method call complete");
		if(auth==null)
		{
			return new ModelAndView("error");
		}
		else
		{
			
			mv= new ModelAndView("retrieveauthorform");
			mv.addObject("Author",auth);
			return mv;
			
		}
			
	}
	@RequestMapping("/updateauthor")
	public ModelAndView updateauthor()
	{	
		System.out.println("received request");
		ModelAndView mv=null;
		Author author=new Author();
		mv= new ModelAndView("updateauthor","author",author);
		mv.addObject("isFirst",true);
		return mv;
	}
	
	@RequestMapping("/updationauthor")
	public ModelAndView updationauthor(@ModelAttribute ("author") @Validated Author author,BindingResult result)
	{	
		System.out.println("Searching the author");
		ModelAndView mv=null;
		Author auth=service.searchAuthor(author);
		if(auth!=null)
		{
		mv=new ModelAndView("updateauthor");
		mv.addObject("Author", auth);
		}
		else
		{
			mv=new ModelAndView("error");
		}
		return mv;
		
	}
	
	@RequestMapping("/updatecomplete")
	public ModelAndView updatecomplete(@ModelAttribute ("author") @Validated Author author,BindingResult result)
	{
		System.out.println("updating the author");
		ModelAndView mv=null;
		Author auth=service.updateAuth(author);
		if(auth!=null)
		{
			mv=new ModelAndView("UpdateSuccess");
			mv.addObject("Author",auth);
		}
		else
		{
			mv=new ModelAndView("error");
		}
		
		
		return mv;
	}
	
	@RequestMapping("/removeauthor")
	public ModelAndView removeauthor()
	{
		ModelAndView mv=null;
		Author author=new Author();
		return new ModelAndView("removeauthorform","author",author);
		
	}

	@RequestMapping("/removeauthorsearch")
	public ModelAndView removeauthorsearch(@ModelAttribute ("author") @Validated Author author,BindingResult result)
	{
		Author auth=service.searchAuthor(author);
		ModelAndView mv;
		if(auth!=null)
		{
			int i=service.removeAuthor(auth);
			mv=new ModelAndView("deleteSuccess");
			mv.addObject("Author",auth);
		}
		else
		{
			mv=new ModelAndView("error");
		}
		
		return mv;
	}
}
