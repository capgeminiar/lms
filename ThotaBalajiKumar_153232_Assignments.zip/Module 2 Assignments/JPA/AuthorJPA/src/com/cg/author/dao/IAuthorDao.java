package com.cg.author.dao;


import com.cg.author.bean.Author;


public interface IAuthorDao {

	Author addAuthor(Author author);

	Author searchAuthor(Author author);

	Author updateAuth(Author author);

	int removeAuthor(Author auth);

}
