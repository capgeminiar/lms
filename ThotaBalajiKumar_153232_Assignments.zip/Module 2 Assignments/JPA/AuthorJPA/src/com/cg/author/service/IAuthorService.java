package com.cg.author.service;

import com.cg.author.bean.Author;


public interface IAuthorService {

	Author addAuthor(Author author);

	Author searchAuthor(Author author);

	Author updateAuth(Author author);

	int removeAuthor(Author auth);

}
