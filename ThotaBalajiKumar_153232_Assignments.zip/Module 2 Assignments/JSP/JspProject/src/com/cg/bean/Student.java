package com.cg.bean;

public class Student {
	private int rollno;
	private String sname;
	private int marks;
	public int getRollno() {
		return rollno;
	}
	public void setRollno(int rollno) {
		this.rollno = rollno;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public int getMarks() {
		return marks;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
	public String getGrade()
	{
		if(marks<40)
		{
			return "Fail";
		}
		else if(marks>=40 && marks<60)
		{
			return "Second Class";
		}
		else if(marks>=60 && marks<75)
		{
			return "First Class";
		}
		else if(marks>=75 && marks<100)
		{
			return "Distinction";
		}
		return sname;
	}
}
