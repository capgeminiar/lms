package com.cg.consumer.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.consumer.bean.BillDTO;
import com.cg.consumer.bean.Consumer;
import com.cg.consumer.exception.EBillException;
import com.cg.consumer.util.DBUtil;

public class ConsumerDao implements IConsumerDao{
	Connection con=null;
	PreparedStatement ps=null;
	ResultSet rs=null;
	Statement s=null;
	
	@Override
	public List<Consumer> getListOfUsers() throws EBillException {
		// TODO Auto-generated method stub
		con = DBUtil.getCon();
		System.err.println("after connection");
		String qry = "select * from consumers";
		List<Consumer> list = null;
		try {
			ps = con.prepareStatement(qry);
			rs = ps.executeQuery();	
			list = new ArrayList<>();
			while ( rs.next() ) {
				Consumer dto = new Consumer();
				dto.setNum((rs.getInt(1)+""));
				dto.setName(rs.getString(2));
				dto.setAddress(rs.getString(3));
				list.add(dto);
				
			}
			
		} catch (SQLException e) {
			throw new EBillException("A technical error has occured");
		}
		return list;
	}
	@Override
	public Consumer searchConsumer(String number) throws EBillException {
		con = DBUtil.getCon();
		String qry = "select * from consumers where consumer_num = ?";
		Consumer dto = null;
		try {
			ps = con.prepareStatement(qry);
			ps.setDouble(1, Double.parseDouble(number));
			rs = ps.executeQuery();				
			if ( rs.next() ) {
				dto = new Consumer();
				dto.setNum((rs.getInt(1)+""));
				dto.setName(rs.getString(2));
				dto.setAddress(rs.getString(3));	
				return dto;
			}else {
				throw new EBillException("Consumer not found");
			}
			
		} catch (SQLException e) {
			throw new EBillException("A technical error has occured");
		}
		
	}
	@Override
	public List<BillDTO> getBillInfo(String number) throws EBillException {
		con = DBUtil.getCon();
		String qry = "select * from billdetails where consumer_num = ?";
		BillDTO dto = null;
		try {
			ps = con.prepareStatement(qry);
			ps.setDouble(1, Double.parseDouble(number));
			rs = ps.executeQuery();	
			List<BillDTO> list = new ArrayList<>();
			while ( rs.next() ) {				
				dto = new BillDTO();
				dto.setBill_num(rs.getDouble("bill_num")+"");
				dto.setConsumer_num(rs.getDouble("consumer_num")+"");
				dto.setCur_reading(rs.getDouble("cur_reading")+"");
				dto.setUnitConsumed(rs.getDouble("unitConsumed")+"");
				dto.setNetAmount(rs.getDouble("netAmount")+"");
				dto.setBill_date(rs.getDate("bill_date"));
				list.add(dto);							
				
			}
			return list;
			
		} catch (SQLException e) {
			throw new EBillException("A technical error has occured"+e);
		}
			
	}
	@Override
	public void addBillInfo(BillDTO dto) throws EBillException {
		con = DBUtil.getCon();
		String qry = "insert into billdetails(bill_num,consumer_num,cur_reading,unitconsumed,netamount,bill_date) values(seq_bill_num.NEXTVAL,?,?,?,?,SYSDATE)";		
		
		try {
			ps = con.prepareStatement(qry);
			ps.setDouble(1, Double.parseDouble(dto.getConsumer_num()));
			ps.setDouble(2, Double.parseDouble(dto.getCur_reading()));
			ps.setDouble(3, Double.parseDouble(dto.getUnitConsumed()));
			ps.setDouble(4, Double.parseDouble(dto.getNetAmount()));					
			int res = ps.executeUpdate();									
						
		} catch (SQLException e) {
			if ( e.getErrorCode()==2291 ) {
				throw new EBillException("Consumer does not exist"+e);
			}
				throw new EBillException("A technical error has occured"+e);
		}
		
	}
		
	}

	


