package com.cg.consumer.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.consumer.bean.BillDTO;
import com.cg.consumer.bean.Consumer;
import com.cg.consumer.dao.ConsumerDao;
import com.cg.consumer.dao.IConsumerDao;
import com.cg.consumer.exception.EBillException;

public class ConsumerServiceImpl implements IConsumerService{
	private IConsumerDao dao=new ConsumerDao();
	@Override
	public List<Consumer> getListOfUsers() throws EBillException {
		// TODO Auto-generated method stub
		return dao.getListOfUsers();
	}

	@Override
	public Consumer searchConsumer(String number) throws EBillException {
		// TODO Auto-generated method stub
		return dao.searchConsumer(number);
	}

	@Override
	public List<BillDTO> getBillInfo(String number) throws EBillException {
		// TODO Auto-generated method stub
		return dao.getBillInfo(number);
	}

	@Override
	public void addBillInfo(BillDTO dto) throws EBillException {
		dao.addBillInfo(dto);
		
	}

	

}
