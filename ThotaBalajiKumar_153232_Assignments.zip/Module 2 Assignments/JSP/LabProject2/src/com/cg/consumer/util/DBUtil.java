package com.cg.consumer.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DBUtil {
	public static Connection getCon()
	{
		InitialContext ctx;
		Connection con=null;
		try {
			System.out.println("in initial context");
			ctx = new InitialContext();
			DataSource ds=(DataSource) ctx.lookup("java:/jdbc/OracleDS");
			con=ds.getConnection();
			
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("In DBUtil con is"+con);
		return con;

}
}
