package com.cg.consumer.controller;



import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.consumer.bean.BillDTO;
import com.cg.consumer.bean.Consumer;
import com.cg.consumer.dao.IConsumerDao;
import com.cg.consumer.exception.EBillException;
import com.cg.consumer.service.ConsumerServiceImpl;
import com.cg.consumer.service.IConsumerService;


@WebServlet("/EBillController")
public class EBillController extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	private IConsumerService service;
       
    
    public EBillController() {
        super();
        
    }

	
	public void init(ServletConfig config) throws ServletException {
		
	}

	
	public void destroy() {
		
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		

		doPost(request, response);
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		

		String action = request.getParameter("action");
		if ( action != null ) {
			
			service = new ConsumerServiceImpl();
			if ( action.equals("ShowListOfUsers") ) {
			
				try {
					List<Consumer> list = service.getListOfUsers();
					request.setAttribute("userListObj", list);
					RequestDispatcher rd = request.getRequestDispatcher("Show_consumer_List.jsp");
					rd.forward(request, response);
				} catch (EBillException e) {
					RequestDispatcher rd = request.getRequestDispatcher("error.jsp");
					request.setAttribute("excpetion", e);
					rd.forward(request, response);
				}
				 				
			}else if ( action.equals("searchConsumer") ) {
								
				RequestDispatcher rd = request.getRequestDispatcher("searchconsumer.jsp");
				rd.forward(request, response);
					
			} else if ( action.equals("Home") ) {
					
				RequestDispatcher rd = request.getRequestDispatcher("Index.jsp");
				rd.forward(request, response);
				
			} else if ( action.equals("ShowConsumer") ) {
				try {
					String number = request.getParameter("consumerNumber");
					
					Consumer consumer = service.searchConsumer(number);
					request.setAttribute("consumerObj", consumer);					
					RequestDispatcher rd = request.getRequestDispatcher("Show_Consumer.jsp");
					rd.forward(request, response);
				} catch (EBillException e) {
					RequestDispatcher rd = request.getRequestDispatcher("error.jsp");
					request.setAttribute("excpetion", e);
					rd.forward(request, response);
				
				}
			
			} else if ( action.equals("showBillDetails") ) {
				String id = request.getParameter("UserID");
				String name = request.getParameter("UserName");
				List<BillDTO> list  = service.getBillInfo(id);
				request.setAttribute("bills", list);
				request.setAttribute("id", id);
				request.setAttribute("name", name);
				RequestDispatcher rd = request.getRequestDispatcher("Show_Bills.jsp");				
				rd.forward(request, response);
				
			}else if ( action.equals("userInfo") ) {
				String id = request.getParameter("UserID");
				String name = request.getParameter("consumerName");
				String cur = request.getParameter("cur");
				request.setAttribute("UserID", id);
				request.setAttribute("cur", cur);
				request.setAttribute("consumerName", name);
				RequestDispatcher rd = request.getRequestDispatcher("User_Info.jsp");				
				rd.forward(request, response);
			}else if( action.equals("calculateBill") ) {
				
				Double last = Double.parseDouble(request.getParameter("lastmonth"));
				Double current = Double.parseDouble(request.getParameter("currentmonth"));
				Double netamount = (current-last) * 1.15D + 100;
				String userID = request.getParameter("UserID");
				String consumerName = request.getParameter("name");
				BillDTO dto = new BillDTO();
				dto.setConsumer_num(userID);
				dto.setCur_reading(current+"");
				dto.setNetAmount(netamount+"");
				dto.setUnitConsumed((current-last)+"");
				try {
					service.addBillInfo(dto);
					request.setAttribute("userID", userID);
					request.setAttribute("consumer_name", consumerName);
					request.setAttribute("current", current);
					request.setAttribute("netamount", netamount);
					RequestDispatcher rd=request.getRequestDispatcher("billinfo.jsp");
					rd.forward(request, response);
				}catch ( EBillException e ) {
					System.out.println(e);
					RequestDispatcher rd = request.getRequestDispatcher("error.jsp");
					request.setAttribute("excpetion", e);
					rd.forward(request, response);
				}
				
				
			}
			else {
				response.getWriter().println("No action defined");
			}
		}
		
	}

}
