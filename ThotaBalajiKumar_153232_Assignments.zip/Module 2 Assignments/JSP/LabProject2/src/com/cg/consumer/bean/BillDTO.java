package com.cg.consumer.bean;

import java.sql.Date;
import java.time.LocalDate;

public class BillDTO {
	
	private String bill_num; 
	private String	consumer_num;
	private String cur_reading;
	private String unitConsumed; 
	private String netAmount; 
	private Date bill_date;
	
	
	public String getBill_num() {
		return bill_num;
	}
	public void setBill_num(String bill_num) {
		this.bill_num = bill_num;
	}
	public String getConsumer_num() {
		return consumer_num;
	}
	public void setConsumer_num(String consumer_num) {
		this.consumer_num = consumer_num;
	}
	public String getCur_reading() {
		return cur_reading;
	}
	public void setCur_reading(String cur_reading) {
		this.cur_reading = cur_reading;
	}
	public String getUnitConsumed() {
		return unitConsumed;
	}
	public void setUnitConsumed(String unitConsumed) {
		this.unitConsumed = unitConsumed;
	}
	public String getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(String netAmount) {
		this.netAmount = netAmount;
	}
	public Date getBill_date() {
		return bill_date;
	}
	public void setBill_date(Date bill_date) {
		this.bill_date = bill_date;
	}
	
	public String getMonth() {
		LocalDate date = bill_date.toLocalDate();
		return date.getMonth().toString();
	}
			
}
