package com.cg.consumer.exception;

public class EBillException extends RuntimeException{
	public EBillException(String msg)  {
		// TODO Auto-generated constructor stub
		System.out.println(msg);
	}

}
