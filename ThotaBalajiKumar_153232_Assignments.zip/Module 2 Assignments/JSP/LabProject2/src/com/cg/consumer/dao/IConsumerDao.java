package com.cg.consumer.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.consumer.bean.BillDTO;
import com.cg.consumer.bean.Consumer;
import com.cg.consumer.exception.EBillException;


public interface IConsumerDao {
List<Consumer> getListOfUsers() throws EBillException;
	
	Consumer searchConsumer(String number) throws EBillException;
	
	List<BillDTO> getBillInfo(String number) throws EBillException;
	
	void addBillInfo(BillDTO dto) throws EBillException;

}
