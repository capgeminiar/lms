package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Trainee;
import com.cg.dao.ITraineeDao;
import com.cg.dao.TraineeDao;

@Service
public class TraineeService implements ITraineeService {

	@Autowired
	ITraineeDao traineeDao;
	
	public ITraineeDao getTraineeDao() {
		return traineeDao;
	}

	public void setTraineeDao(ITraineeDao traineeDao) {
		this.traineeDao = traineeDao;
	}

	@Override
	public Trainee addTrainee(Trainee trainee) {
		return traineeDao.addTrainee(trainee);
	}

	@Override
	public Trainee deleteTrainee(int traineeId) {
		// TODO Auto-generated method stub
		return traineeDao.deleteTrainee(traineeId);
	}

	@Override
	public Trainee modifyTrainee(int traineeId,Trainee trainee) {
		
		return traineeDao.modifyTrainee(traineeId,trainee);
	}

	@Override
	public Trainee getTraineeDetails(int TraineeId) {
		
		return traineeDao.getTraineeDetails(TraineeId);
	}

	@Override
	public List<Trainee> getAllTraineeDetails() {
		// TODO Auto-generated method stub
		return traineeDao.getAllTraineeDetails();
	}
	
}
