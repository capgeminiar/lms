package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.bean.Login1;
import com.cg.bean.Trainee;
import com.cg.service.ITraineeService;

@Controller
public class TraineeController {
	
	@Autowired
	private ITraineeService traineeService;
	ArrayList<String> domainList;
	
	public ITraineeService getTraineeService() {
		return traineeService;
	}

	public void setTraineeService(ITraineeService traineeService) {
		this.traineeService = traineeService;
	}

	@RequestMapping("/showLoginPage")
	public String showLogin(Model model)
	{
		System.out.println("In prepareLogin() method");
		model.addAttribute("Login1",new Login1());
		return "Login1";
	}
	
	@RequestMapping("/Options")
	public String showHomePage() 
	{
		return "Options";
		
	}
	
	@RequestMapping("/checkLogin")
	public ModelAndView checkLogin(@ModelAttribute("Login1") @Validated Login1 l,BindingResult result)
	{
		if(!result.hasErrors())
			return new ModelAndView("Options");	
		else
			return new ModelAndView("Login1","Login1",l);
	}
	
	@RequestMapping("/showAddTrainee")
	public String showAddTrainee(Model model) {
		Trainee trainee = new Trainee();
		
		domainList=new ArrayList<String>();
		domainList.add("JEE");
		domainList.add("JavaScript");
		domainList.add("Cloud");
		
		model.addAttribute("domainList", domainList);
		model.addAttribute("trainee", trainee);
		return "AddTrainee";
	}

	@RequestMapping("/addTrainee")
	public ModelAndView addTrainee(
			@ModelAttribute("trainee") @Valid Trainee trainee,BindingResult result) 
	{

		ModelAndView mv = null;
		
		if (!result.hasErrors()) {
			System.out.println(trainee);
			Trainee tr = traineeService.addTrainee(trainee);
			mv = new ModelAndView("addSuccess","traineeId",tr.getTraineeId());
			
		} else {
			domainList=new ArrayList<String>();
			domainList.add("JEE");
			domainList.add("JavaScript");
			domainList.add("Cloud");
			mv = new ModelAndView("AddTrainee", "trainee", trainee);
			mv.addObject("domainList",domainList);
			
		}

		return mv;
	}
	@RequestMapping("/retrieveTrainee")
	public ModelAndView showViewTraineeForm() {

		// Create an attribute of type Question
		Trainee trainee = new Trainee();
		// Add the attribute to the model and return along with
		// the view name
		ModelAndView mv = new ModelAndView("viewTrainee");
		mv.addObject("trainee", trainee);
		mv.addObject("isFirst", "true");

		return mv;
	}
	
	@RequestMapping("/viewTrainee")
	public ModelAndView getTraineeDetails(@ModelAttribute("trainee") Trainee trainee) {

		ModelAndView mv = new ModelAndView();

		Trainee tBean = new Trainee();
		tBean = traineeService.getTraineeDetails(trainee.getTraineeId());

		if (tBean != null) {
			mv.setViewName("viewTrainee");
			mv.addObject("tBean", tBean);
		} else {
			String msg = "Enter a Valid Id!!";
			mv.setViewName("myError");
			mv.addObject("msg", msg);
		}

		return mv;
	}

	@RequestMapping("/showViewAllTrainee")
	public ModelAndView getAllTraineeDetails() {

		ModelAndView mv = new ModelAndView();

		List<Trainee> list = traineeService.getAllTraineeDetails();
		if (list.isEmpty()) {
			String msg = "There are no Trainers";
			mv.setViewName("myError");
			mv.addObject("msg", msg);
		} else {
			mv.setViewName("viewAllTrainee");
			// Add the attribute to the model
			mv.addObject("list", list);
		}
		return mv;
	}
	
	@RequestMapping("/showDeleteTrainee")
	public ModelAndView showDeleteTraineeForm() {

		// Create an attribute of type Question
		Trainee trainee = new Trainee();
		// Add the attribute to the model and return along with
		// the view name
		ModelAndView mv = new ModelAndView("deleteTrainee");
		mv.addObject("trainee", trainee);
		mv.addObject("isFirst", "true");

		return mv;
	}
	
	@RequestMapping("/deleteTrainee")
	public ModelAndView deleteTrainee(@ModelAttribute("trainee") Trainee trainee) {

		ModelAndView mv = new ModelAndView();

		Trainee tBean = new Trainee();
		tBean = traineeService.deleteTrainee(trainee.getTraineeId());
		System.out.println(tBean);
		if (tBean != null) {
			mv.setViewName("deleteTrainee");
			mv.addObject("tBean", tBean);
		} else {
			String msg = "Enter a Valid Id!!";
			mv.setViewName("myError");
			mv.addObject("msg", msg);
		}

		return mv;
	}
	
	@RequestMapping("/showUpdateTrainee")
	public ModelAndView showUpdateTraineeForm() {

		Trainee trainee = new Trainee();
		ModelAndView mv = new ModelAndView("updateTrainee");
		mv.addObject("trainee", trainee);
		mv.addObject("isFirst", "true");

		return mv;
	}
	
	@RequestMapping("/updateTraineeView")
	public ModelAndView viewUpdateTrainee(@ModelAttribute("trainee") Trainee trainee) {

		ModelAndView mv = new ModelAndView();

		Trainee tBean = new Trainee();
		tBean = traineeService.getTraineeDetails(trainee.getTraineeId());

		if (tBean != null) {
			mv.setViewName("updateTrainee");
			mv.addObject("tBean", tBean);
		} else {
			String msg = "Enter a Valid Id!!";
			mv.setViewName("myError");
			mv.addObject("msg", msg);
		}

		return mv;
	}
	
	@RequestMapping("/updateTraineeSet")
	public ModelAndView updateTraineeSet(@ModelAttribute("trainee") Trainee trainee) {

		
		ModelAndView mv = null;
		
		if (trainee!=null) {
			System.out.println(trainee);
			Trainee tr = traineeService.modifyTrainee(trainee.getTraineeId(),trainee);
			System.out.println(tr);
			mv = new ModelAndView("addSuccess","traineeId",tr.getTraineeId());
		} else {
			mv = new ModelAndView();
			mv.setViewName("updateTrainee");
			mv.addObject("tBean", trainee);
		}

		return mv;
	}
}




