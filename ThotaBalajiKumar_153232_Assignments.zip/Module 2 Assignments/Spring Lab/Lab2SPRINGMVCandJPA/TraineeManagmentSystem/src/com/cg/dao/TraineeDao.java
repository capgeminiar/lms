package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.bean.Trainee;



@Repository
@Transactional
public class TraineeDao implements ITraineeDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public Trainee addTrainee(Trainee trainee) {
		entityManager.persist(trainee); //Manage means Persist
		entityManager.flush();  //Synchronization means flush
		return trainee;	
	}

	@Override
	public Trainee deleteTrainee(int traineeId) {
		Trainee tBean=entityManager.find(Trainee.class, traineeId);
		entityManager.remove(tBean);
		entityManager.flush();
		return tBean;
		
	}

	@Override
	public Trainee modifyTrainee(int traineeId,Trainee trainee) {
		
		Trainee tBean=entityManager.find(Trainee.class, traineeId);
		tBean.setTraineeName(trainee.getTraineeName());
		tBean.setTraineeLocation(trainee.getTraineeLocation());
		tBean.setTraineeDomain(trainee.getTraineeDomain());
		entityManager.merge(tBean);
		return tBean;
	}

	@Override
	public Trainee getTraineeDetails(int TraineeId) {
		return entityManager.find(Trainee.class, TraineeId);
	}

	@Override
	public List<Trainee> getAllTraineeDetails() {
		TypedQuery<Trainee> query = entityManager.createQuery("SELECT t FROM Trainee t", Trainee.class);
		return query.getResultList();
	}
	
	
	

}
