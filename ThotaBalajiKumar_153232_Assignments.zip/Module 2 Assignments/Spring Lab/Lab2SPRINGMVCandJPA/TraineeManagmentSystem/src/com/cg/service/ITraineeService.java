package com.cg.service;

import java.util.List;

import com.cg.bean.Trainee;



public interface ITraineeService {

	public Trainee addTrainee(Trainee trainee);
	public Trainee deleteTrainee(int TraineeId);
	public Trainee modifyTrainee(int traineeId,Trainee trainee);
	public Trainee getTraineeDetails(int TraineeId);
	public List<Trainee> getAllTraineeDetails();
	
}
