package com.cg.bean;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

public class Login1 {
	
	@NotEmpty(message="Please Enter Username")
	@Pattern(regexp = "admin", message = "Wrong username")
	private String userName;
	
	@NotEmpty(message="Please Enter Password")
	@Pattern(regexp = "admin", message = "Wrong Password")
	private String password;
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	

}
