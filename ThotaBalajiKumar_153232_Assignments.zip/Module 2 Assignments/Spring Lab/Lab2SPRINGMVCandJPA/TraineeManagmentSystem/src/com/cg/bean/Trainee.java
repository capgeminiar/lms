package com.cg.bean;




import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

@Entity
@Table(name="Trainee")
public class Trainee {
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="trainee_seq")
	@SequenceGenerator(name="trainee_seq", initialValue=1000, allocationSize=1)
	private int traineeId;
	
	@NotEmpty(message="Please Enter Donor Name")
	@Pattern(regexp = "^[a-zA-Z]+$", message = "Username must contain only alphabets")
	private String traineeName;
	
	@NotEmpty(message="Please Enter Donor Name")
	@Pattern(regexp = "^[a-zA-Z]+$", message = "Username must contain only alphabets")
	private String traineeDomain;
	
	@NotEmpty(message="Please Enter Donor Name")
	@Pattern(regexp = "^[a-zA-Z]+$", message = "Username must contain only alphabets")
	private String traineeLocation;
	
	@Pattern(regexp="^[0-9]+$",message="Please Enter valid amount greater than 0")
	@Range(min = 10000, max = 30000)
	private String traineeAmount;

	public int getTraineeId() {
		return traineeId;
	}

	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}
	public String getTraineeName() {
		return traineeName;
	}
	
	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}
	public String getTraineeDomain() {
		return traineeDomain;
	}
	public void setTraineeDomain(String traineeDomain) {
		this.traineeDomain = traineeDomain;
	}
	public String getTraineeLocation() {
		return traineeLocation;
	}
	public void setTraineeLocation(String traineeLocation) {
		this.traineeLocation = traineeLocation;
	}

	public String getTraineeAmount() {
		return traineeAmount;
	}

	public void setTraineeAmount(String traineeAmount) {
		this.traineeAmount = traineeAmount;
	}

	@Override
	public String toString() {
		return "Trainee [traineeId=" + traineeId + ", traineeName=" + traineeName + ", traineeDomain=" + traineeDomain
				+ ", traineeLocation=" + traineeLocation + ", traineeAmount=" + traineeAmount + "]";
	}

	

	
	
	

	

}
