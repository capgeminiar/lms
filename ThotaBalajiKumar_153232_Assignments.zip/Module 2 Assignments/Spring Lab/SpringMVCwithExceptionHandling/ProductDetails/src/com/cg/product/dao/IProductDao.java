package com.cg.product.dao;

import com.cg.product.beans.ProductBean;
import com.cg.product.exception.ProductException;

public interface IProductDao {
	
	public ProductBean addProduct(ProductBean product);
	
	public ProductBean getProductDetails(int productId);
	

}
