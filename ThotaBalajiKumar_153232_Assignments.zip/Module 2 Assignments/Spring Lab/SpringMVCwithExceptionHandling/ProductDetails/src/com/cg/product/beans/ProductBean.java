package com.cg.product.beans;



import java.util.Arrays;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="ProductBean")
public class ProductBean{
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int productId;
	
	@NotEmpty(message="Please Choose categoryofProuct")
	private String categoryProduct;
	
	@NotEmpty(message="Please Enter Product Name")
	@Pattern(regexp = "^[a-zA-Z]+$", message = "Product Name must contain only alphabets")
	private String productName;

	@NotNull(message="Please Enter Product Price")
	@Min(value=5)
	private int productPrice;
	
	
	
	@NotEmpty(message="Please Select Location from given options")
	private String location;
	
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getCategoryProduct() {
		return categoryProduct;
	}
	public void setCategoryProduct(String categoryProduct) {
		this.categoryProduct = categoryProduct;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
	
	
	
	
	

}
