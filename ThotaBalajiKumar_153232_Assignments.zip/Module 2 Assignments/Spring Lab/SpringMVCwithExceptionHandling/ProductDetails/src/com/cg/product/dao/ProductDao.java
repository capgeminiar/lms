package com.cg.product.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.product.beans.ProductBean;
import com.cg.product.exception.ProductException;


@Repository
@Transactional
public class ProductDao implements IProductDao{

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public ProductBean addProduct(ProductBean product) {
		try {
			entityManager.persist(product); //Manage means Persist
			entityManager.flush();   //Synchronization means flush
		} catch (Exception e) {
			throw new ProductException("Exception in Dao"+e.getMessage());			
		} 	 
		return product;
	}

	@Override
	public ProductBean getProductDetails(int productId) {
		try {
			return entityManager.find(ProductBean.class, productId);
		}
		catch(Exception e) {
			throw new ProductException("Exception in Dao in getting details: "+e.getMessage());
		}
	}

}
