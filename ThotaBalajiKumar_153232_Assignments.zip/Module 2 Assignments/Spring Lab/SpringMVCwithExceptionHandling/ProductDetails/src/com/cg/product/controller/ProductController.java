package com.cg.product.controller;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.product.beans.ProductBean;
import com.cg.product.exception.ProductException;
import com.cg.product.service.IProductService;

@Controller
public class ProductController {
	
	@Autowired
	private IProductService productService;
	ArrayList<String> categoryList;
	ArrayList<String> locationList;
	
	public IProductService getProductService() {
		return productService;
	}
	public void setProductService(IProductService productService) {
		this.productService = productService;
	}
	
	
	@RequestMapping("/showHomePage")
	public String showHomePage() 
	{
		return "HomePage";
		
	}
	
	@RequestMapping("/showAddProduct")
	public String showAddProduct(Model model) {
		
		ProductBean productBean = new ProductBean();
		
		categoryList=new ArrayList<String>();
		categoryList.add("Laptops");
		categoryList.add("TV");
		categoryList.add("Mobiles");
		
		locationList =new ArrayList<String>();
		locationList.add("Mumbai");
		locationList.add("Pune");
		locationList.add("Bangalore");
		locationList.add("Chennai");
		
		model.addAttribute("categoryList", categoryList);
		model.addAttribute("locationList", locationList);
		model.addAttribute("productBean", productBean);
		
		return "addProduct";
	}
	
	@RequestMapping("/addProduct")
	public ModelAndView addProduct(
			@ModelAttribute("productBean") @Valid ProductBean productBean,BindingResult result) 
	{

		ModelAndView mv = null;
		
		if (!result.hasErrors()) {			
			productBean = productService.addProduct(productBean);
			mv = new ModelAndView("addSuccess","productId",productBean.getProductId());
			
		} else {
			
			categoryList=new ArrayList<String>();
			categoryList.add("Laptops");
			categoryList.add("TV");
			categoryList.add("Mobiles");	
			locationList =new ArrayList<String>();
			locationList.add("Mumbai");
			locationList.add("Pune");
			locationList.add("Bangalore");
			locationList.add("Chennai");
			mv = new ModelAndView("addProduct", "productBean", productBean);
			mv.addObject("categoryList",categoryList);
			mv.addObject("locationList",locationList);
			
		}
		return mv;
	}
	
	@RequestMapping("/showViewProduct")
	public ModelAndView showViewProductForm() {

		// Create an attribute of type Question
		ProductBean productBean = new ProductBean();
		// Add the attribute to the model and return along with
		// the view name
		ModelAndView mv = new ModelAndView("viewProduct");
		mv.addObject("productBean", productBean);
		mv.addObject("isFirst", "true");

		return mv;
	}

	@RequestMapping("/viewProduct")
	public ModelAndView viewProduct(@ModelAttribute("productBean") ProductBean productBean){

		ModelAndView mv = new ModelAndView();
		
		productBean = productService.getProductDetails(productBean.getProductId());

		if (productBean != null) {
			
			mv.setViewName("viewProduct");
			mv.addObject("productBean", productBean);
		} else {	
			throw new ProductException("Product details not found");
		}

		return mv;
	}
	

}
