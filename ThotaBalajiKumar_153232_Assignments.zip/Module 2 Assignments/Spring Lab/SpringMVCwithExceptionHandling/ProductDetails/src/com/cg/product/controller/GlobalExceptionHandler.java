package com.cg.product.controller;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import com.cg.product.exception.ProductException;

@ControllerAdvice
public class GlobalExceptionHandler {
	
	@ExceptionHandler(value = {ProductException.class})
    protected ModelAndView handleConflict(ProductException ex) {
		ModelAndView model = new ModelAndView("error");
		model.addObject("errMsg", ex.getMessage());
		return model;
    }
}
