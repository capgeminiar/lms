package com.cg.product.service;

import com.cg.product.beans.ProductBean;

public interface IProductService {
	
	public ProductBean addProduct(ProductBean product);
	
	public ProductBean getProductDetails(int productId);

}
