package com.cg.ui;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.cg.bean.sbuDetails;


public class EmpDisplay {
	public static void main(String[] args) {
		Resource res = new ClassPathResource("Demo1.xml");
		BeanFactory vf = new XmlBeanFactory(res);
		sbuDetails sbu=(sbuDetails) vf.getBean("sbu1");
		System.out.println(sbu);
	}
	
			

}
