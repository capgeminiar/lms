package com.cg.ui;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.cg.bean.Employee;


public class EmpDisplay {
	public static void main(String[] args) {
		Resource res = new ClassPathResource("Demo1.xml");
		BeanFactory vf = new XmlBeanFactory(res);
		Employee emp=(Employee) vf.getBean("emp");
		System.out.println("Employee Details");
		System.out.println("---------------------");
		System.out.println("Employee ID: "+ emp.getEmployeeId());
		System.out.println("Employee Name :"+ emp.getEmployeeName());
		System.out.println("Employee Salary : "+emp.getSalary());
		System.out.println("Employee BU : "+emp.getBusinessUnit());
		System.out.println("Employee Age : "+emp.getAge());
	}
	
			

}
