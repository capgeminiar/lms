package com.cg;

import java.util.Scanner;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class EmployeeMain {
	
	
	public static void main(String args[]) throws Exception {
		Scanner sc=new Scanner(System.in);
		Resource context = new ClassPathResource("beans.xml");
		BeanFactory bf=new XmlBeanFactory(context);
		EmployeeService service = (EmployeeService) bf.getBean("empService"); 
		System.out.println("Employee ID      :");
		int id=sc.nextInt();
		Employee e=service.showDetails(id);
		if(e!=null) {
		 System.out.println("Employee Info: ");
		 System.out.println("Employee ID : "+e.getEmpId());
		 System.out.println("Employee Name : "+e.getEmpName());
		 System.out.println("Employee SALARY: "+e.getEmpSal());
		}
		else {
			System.out.println("Employee Not found");
		}
	}

}
