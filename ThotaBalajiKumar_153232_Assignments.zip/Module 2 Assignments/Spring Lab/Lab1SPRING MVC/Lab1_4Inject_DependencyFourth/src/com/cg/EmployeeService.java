package com.cg;

public class EmployeeService {
	
	
	EmployeeDao empDao;
	
	public EmployeeDao getEmpDao() {
		return empDao;
	}

	public void setEmpDao(EmployeeDao empDao) {
		this.empDao = empDao;
	}

	public Employee showDetails(int empId){
		return empDao.showDetails(empId);
		
	}
}
