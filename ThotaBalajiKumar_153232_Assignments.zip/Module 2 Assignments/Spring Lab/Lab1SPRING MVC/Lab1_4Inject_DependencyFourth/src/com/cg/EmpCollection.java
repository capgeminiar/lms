package com.cg;

import java.util.List;

public class EmpCollection {
	
	List<Employee> el;

	public List<Employee> getEl() {
		return el;
	}

	public void setEl(List<Employee> el) {
		this.el = el;
	}
	

}
