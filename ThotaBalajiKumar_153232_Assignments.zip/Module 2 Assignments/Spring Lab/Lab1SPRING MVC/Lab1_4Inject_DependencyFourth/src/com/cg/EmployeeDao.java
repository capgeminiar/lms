package com.cg;


import java.util.List;


public class EmployeeDao {
	
	

	EmpCollection eCol;
	
	public EmpCollection geteCol() {
		return eCol;
	}

	public void seteCol(EmpCollection eCol) {
		this.eCol = eCol;
	}

	public Employee showDetails(int empId){
		
		List<Employee> el=eCol.getEl();
		for(Employee e:el)
		{
		if(empId==e.getEmpId()) {
			return e;
		}
		}
		return null;
	}
	
	
	

}
