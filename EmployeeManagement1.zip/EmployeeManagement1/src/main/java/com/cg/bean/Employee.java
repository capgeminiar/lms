package com.cg.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table(name = "EMP")
public class Employee implements Serializable {
 
	 

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", ename=" + ename + ", email="
				+ email + ", uname=" + uname + ", pass=" + pass + ", mgr="
				+ mgr + ", job=" + job + ", sal=" + sal + "]";
	}
	public Employee() {
		super();
	}
	
    private static final long serialVersionUID = -3465813074586302847L;
    @Id
	@Column(name = "empid")
    @SequenceGenerator(name="empid",sequenceName="emp_id_seq",allocationSize=1)
    @GeneratedValue(generator="empid",strategy=GenerationType.SEQUENCE)
    private int empId;
    
    
    private String ename;
    
    @Column(name = "email")
    private String email;
    
    @Column(name = "username")
    private String uname;
    
    @Column(name = "PASSWORD")
    private String pass;
    
    @Column(name = "mgr")
    private String mgr;
    
    @Column(name = "job")
    private String job;
    
    @Column(name = "sal")
    private int sal;
     
	
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getMgr() {
		return mgr;
	}
	public void setMgr(String mgr) {
		this.mgr = mgr;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public int getSal() {
		return sal;
	}
	public void setSal(int sal) {
		this.sal = sal;
	}
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}