package com.cg.service;

import java.util.List;

import com.cg.bean.Employee;

public interface IEmployeeService {

	public abstract void addEmployee(Employee emp);

	public abstract List<Employee> getAllEmployee();

	public abstract Employee getEmployeeById(int empId);

	public abstract void deleteEmployee(int empId);

	public abstract int updateEmployee(Employee emp);

}