package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.bean.Employee;
import com.cg.bean.Status;
import com.cg.dao.EmployeeDAO;

@Service("employeeService")
@Transactional
public class EmployeeService {

	@Autowired
	EmployeeDAO empDao;

	public void addEmployee(Employee emp) {
		empDao.addEmployee(emp);
	}

	public List<Employee> getAllEmployee() {
		return empDao.getAllEmp();
	}

	public Employee getEmployeeById(int empId) {
		return empDao.getEmployeeById(empId);

	}

	public void deleteEmployee(int empId) {
		empDao.deleteEmployee(empId);
	}

	public int updateEmployee(Employee emp) {
		return empDao.updateEmployee(emp);
	}

	public void addStatus(Status status) {
		empDao.addStatus(status);
	}

	public List<Status> getAllStatus() {
		return empDao.getAllStatus();
	}

	public Status getStatusById(String statusId) {
		return empDao.getStatusById(statusId);
	}
	
	public Status editStatus(Status status)
	{
		return empDao.editStatus(status);
	}
	public List<Status> getDetailsByDate(String sDate,String eDate,int empId)
	{
		return empDao.getDetailsByDate(sDate, eDate,empId);
	}
}
