package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.bean.Employee;
import com.cg.bean.Status;

@Repository("employeeDAO")
public class EmployeeDAO {

	@PersistenceContext
	private EntityManager entityManager;

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public void addEmployee(Employee emp) {

		entityManager.persist(emp);
	}

	public List<Employee> getAllEmp() {
		String str = "SELECT emp FROM Employee emp";
		TypedQuery<Employee> query = entityManager.createQuery(str,
				Employee.class);
		return query.getResultList();
	}

	public Employee getEmployeeById(int employeeId) {
		return entityManager.find(Employee.class, employeeId);

	}

	public void deleteEmployee(int empId) {
		Query query = entityManager
				.createNativeQuery("DELETE FROM emp WHERE empId = " + empId);
		query.executeUpdate();
	}

	public int updateEmployee(Employee emp) {
		entityManager.merge(emp);
		return 0;
	}

	public void addStatus(Status status) {
		entityManager.persist(status);
	}

	public List<Status> getAllStatus() {
		String str = "SELECT st FROM Status st";
		TypedQuery<Status> query = entityManager.createQuery(str, Status.class);
		return query.getResultList();
	}
	public Status getStatusById(String statusId) {
		return entityManager.find(Status.class, statusId);

	}
	public Status editStatus(Status status)
	{
		return entityManager.merge(status);
	}
	public List<Status> getDetailsByDate(String sDate,String eDate,int empId)
	{
		String str= "SELECT st FROM Status st WHERE st.date BETWEEN '"+sDate+"' AND '"+eDate+"' "
				+ "AND st.empId="+ empId;
		TypedQuery<Status> query = entityManager.createQuery(str,
				Status.class);
		return query.getResultList();
		
	}

}
