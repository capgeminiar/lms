package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;

import com.cg.bean.Employee;

public interface IEmployeeDAO {

	public abstract void setEntityManager(EntityManager entityManager);

	public abstract void addEmployee(Employee emp);

	public abstract List<Employee> getAllEmp();

	public abstract Employee getEmployeeById(int employeeId);

	public abstract void deleteEmployee(int empId);

	public abstract int updateEmployee(Employee emp);

}