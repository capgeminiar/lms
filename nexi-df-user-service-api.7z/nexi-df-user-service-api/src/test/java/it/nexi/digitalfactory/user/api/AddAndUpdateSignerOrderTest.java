package it.nexi.digitalfactory.user.api;

import java.io.File;
import java.io.IOException;

import org.aspectj.lang.annotation.Before;
import org.assertj.core.api.Assertions;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import it.nexi.digitalfactory.user.api.domain.UserSignerSignGroupJson;
import it.nexi.digitalfactory.user.api.exception.UnableToSaveOrUpdateOrder;
import it.nexi.digitalfactory.user.api.exception.UserNotAuthorized;
import it.nexi.digitalfactory.user.api.restController.SignOrderRestController;
import junit.framework.TestCase;

@RunWith(SpringRunner.class)
@SpringBootTest
public class AddAndUpdateSignerOrderTest extends TestCase {

	@Autowired
	public SignOrderRestController signOrderRestControlerObject; 
	private ObjectMapper mapper;
	public UserSignerSignGroupJson updateSignerSignGroupJsonObj;
	
	@Override
	protected void setUp() throws Exception {
		super.setUp();
	}
	
	@org.junit.Before
	public void fieldInitializer() {
		 mapper = new ObjectMapper();		
	}
	
	@Test
	public void testAddSignerOrderSuccess() {
		try {
			updateSignerSignGroupJsonObj =  mapper.readValue(new File("./src/test/resources/addOrderSuccess.json"),
					    UserSignerSignGroupJson.class);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		Assertions.assertThatCode(() -> signOrderRestControlerObject.addSignerOrderForGroup(updateSignerSignGroupJsonObj)).doesNotThrowAnyException();
	}
	
	@Test(expected = UserNotAuthorized.class)
	public void testAddSignerOrderWithWrongAdminFails() {
		try {
			updateSignerSignGroupJsonObj =  mapper.readValue(new File("./src/test/resources/addOrderWithInvalidCredentials.json"),
					    UserSignerSignGroupJson.class);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		signOrderRestControlerObject.addSignerOrderForGroup(updateSignerSignGroupJsonObj);
	}
	
	
	@Test
	public void testUpdateSignerOrderSuccess() {
		try {
			preUpdateSetup(mapper);
		   updateSignerSignGroupJsonObj = mapper.readValue(new File("./src/test/resources/updateOrderSuccess.json"),
			    UserSignerSignGroupJson.class);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		Assertions.assertThatCode(() -> signOrderRestControlerObject.addSignerOrderForGroup(updateSignerSignGroupJsonObj)).doesNotThrowAnyException();
	}
	
	
	
	@Test(expected = UnableToSaveOrUpdateOrder.class)
	public void testUpdateSignerOrderWithSignerOrderAssignedToOtherSignerFails() {
		try {
			preUpdateSetup(mapper);
			updateSignerSignGroupJsonObj = mapper.readValue(new File("./src/test/resources/updateOrderWithOrderAlreadyAssignedFails.json"),
				    UserSignerSignGroupJson.class);
			signOrderRestControlerObject.addSignerOrderForGroup(updateSignerSignGroupJsonObj);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
	}
	
    @Test
	public void testUpdateSignerOrderWithSameOrderSuccess() {
		try {
			preUpdateSetup(mapper);
			updateSignerSignGroupJsonObj =  mapper.readValue(new File("./src/test/resources/updateSignerOrderWithSameOrder.json"),
					    UserSignerSignGroupJson.class);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		Assertions.assertThatCode(() -> signOrderRestControlerObject.addSignerOrderForGroup(updateSignerSignGroupJsonObj)).doesNotThrowAnyException();
	}
    
	private void preUpdateSetup(ObjectMapper mapper) throws IOException, JsonParseException, JsonMappingException {
		updateSignerSignGroupJsonObj =  mapper.readValue(new File("./src/test/resources/addOrderSuccess.json"),
			    UserSignerSignGroupJson.class);
		signOrderRestControlerObject.addSignerOrderForGroup(updateSignerSignGroupJsonObj);
	}
	
	@Override
	protected void tearDown() throws Exception {
		super.tearDown();
	}

}
