package it.nexi.digitalfactory.user.api.restController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import it.nexi.digitalfactory.user.api.domain.SignerDetailsJson;
import it.nexi.digitalfactory.user.api.domain.UserSignerDispositionSign;
import it.nexi.digitalfactory.user.api.domain.UserSignerSignGroup;
import it.nexi.digitalfactory.user.api.domain.UserSignerSignGroupJson;
import it.nexi.digitalfactory.user.api.services.SignerOrderService;

@RestController
@RequestMapping("/signOrder")
public class SignOrderRestController {
    @Autowired
    private SignerOrderService usersignersigngroupService;

    @Autowired
    public void setusersignersigngroupService(SignerOrderService UsersignersigngroupService) {
        this.usersignersigngroupService = UsersignersigngroupService;
    }

    @PostMapping("/addSignerOrderForGroup")
    public void addSignerOrderForGroup(@RequestBody UserSignerSignGroupJson userSignerSignGroupJson )
    { 
    	usersignersigngroupService.addSignerOrderForGroup( userSignerSignGroupJson.getLoginSignerName(),
    			userSignerSignGroupJson.getSignerDetails(),
    			userSignerSignGroupJson.getGroupName());
    }
    
    @RequestMapping(value = "/getSignerOrderForGroup/{groupName}", method= RequestMethod.GET, produces = "application/json")
    public List<SignerDetailsJson> getSignerOrderForGroup(@PathVariable int groupName){
        return usersignersigngroupService.getSignerOrderForGroup(groupName);
    }
    
    @PostMapping("/saveSignerDetails")
    public void saveSignerDetails(@RequestBody UserSignerDispositionSign userSignerDispositionSign )
    { 

    	  usersignersigngroupService.saveSignerDetails(userSignerDispositionSign.getLoginSignerName(), userSignerDispositionSign);
    }

    @RequestMapping(value = "/validateSignatureOrder" , method= RequestMethod.GET, produces = "application/json")
    public String validateSignatureOrder(@RequestBody UserSignerSignGroupJson userSignerSignGroup )
    { 

    	  return usersignersigngroupService.validateSignatureOrder(userSignerSignGroup.getSignerDetails().get(0).getSignerName(),
    			  userSignerSignGroup.getGroupName(), userSignerSignGroup.getSignerDetails().get(0).getSignerOrder());
    }

}
