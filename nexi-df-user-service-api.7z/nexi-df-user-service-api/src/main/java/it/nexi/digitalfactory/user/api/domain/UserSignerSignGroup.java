package it.nexi.digitalfactory.user.api.domain;


import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "UserSignerSignGroup")
@Data
public class UserSignerSignGroup implements Serializable {


	/**
	 * 
	 */
	private static final long serialVersionUID = -3677593457451317254L;


	public UserSignerSignGroup() {

    }
	
	private int signerOrder;
    
	@EmbeddedId
    private SignerDetails signerDetails;
}
