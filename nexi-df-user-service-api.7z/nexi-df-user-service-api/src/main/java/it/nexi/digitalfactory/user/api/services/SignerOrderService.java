package it.nexi.digitalfactory.user.api.services;

import java.util.List;
import java.util.Map;

import it.nexi.digitalfactory.user.api.domain.SignerDetails;
import it.nexi.digitalfactory.user.api.domain.SignerDetailsJson;
import it.nexi.digitalfactory.user.api.domain.UserSignerDispositionSign;


public interface SignerOrderService {


      void addSignerOrderForGroup(String loggedInUserID, List<SignerDetailsJson> signerDetailsList, int groupName);
      
      List<SignerDetailsJson> getSignerOrderForGroup(int groupName );
      
      void saveSignerDetails(String loggedInUserID, UserSignerDispositionSign dispositionSign);
      
      String validateSignatureOrder(String signerName, int groupName, Integer order);
      
      
}
