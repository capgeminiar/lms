package it.nexi.digitalfactory.user.api.domain;

import lombok.Data;

@Data
public class SignerDetailsJson {
	String signerName;
	Integer signerOrder;
}
