package it.nexi.digitalfactory.user.api.exception;

public class UserNotAuthorized extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2724488235306684648L;
	
	public UserNotAuthorized(String exception) {
		super(exception);
	}

}
