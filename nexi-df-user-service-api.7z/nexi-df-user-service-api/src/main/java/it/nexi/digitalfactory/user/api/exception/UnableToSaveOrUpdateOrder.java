package it.nexi.digitalfactory.user.api.exception;

public class UnableToSaveOrUpdateOrder extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2724488235306684648L;
	
	public UnableToSaveOrUpdateOrder(String exception) {
		super("Unable to save or update order of group" + exception);
	}

}
