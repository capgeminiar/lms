package it.nexi.digitalfactory.user.api.services;

import java.util.ArrayList;
import java.util.HashSet;
//import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.nexi.digitalfactory.user.api.domain.LogginUserDetailsTable;
import it.nexi.digitalfactory.user.api.domain.SignerDetails;
import it.nexi.digitalfactory.user.api.domain.SignerDetailsJson;
import it.nexi.digitalfactory.user.api.domain.UserSignerDispositionSign;
import it.nexi.digitalfactory.user.api.domain.UserSignerSignGroup;
import it.nexi.digitalfactory.user.api.exception.GroupNotFound;
import it.nexi.digitalfactory.user.api.exception.UnableToSaveOrUpdateOrder;
import it.nexi.digitalfactory.user.api.exception.UserNotAuthorized;
import it.nexi.digitalfactory.user.api.repositories.LogginSignerRepositiory;
import it.nexi.digitalfactory.user.api.repositories.UserSignerDispositionSignRepositiory;
import it.nexi.digitalfactory.user.api.repositories.UserSignerRepository;
@Service
public class SignerOrderServiceImpl implements SignerOrderService {
    @Autowired
    private UserSignerRepository userSignerRepository;
    
    @Autowired
    private UserSignerDispositionSignRepositiory userSignerDispositionSignRepositiory; 
    
    @Autowired
    private LogginSignerRepositiory logginSignerRepositiory; 

    @Override
    public void addSignerOrderForGroup(String loggedInUserID, List<SignerDetailsJson> signerDetailsList,
            int groupName) {
    	
        if(loggedInUserID != null)
        {
            checkLoggedInUserIsAuthorized(loggedInUserID);
        }
        
        checkDuplicateOrder(groupName, signerDetailsList);
        
            if(!signerDetailsList.isEmpty()) {
                for (SignerDetailsJson signerDetailsJson : signerDetailsList) {
                    UserSignerSignGroup userSignerSignGroup = new UserSignerSignGroup();
                    SignerDetails signerDetail = new SignerDetails();
                    signerDetail.setSignerName(signerDetailsJson.getSignerName());
                    userSignerSignGroup.setSignerOrder(signerDetailsJson.getSignerOrder());
                    signerDetail.setGroupName(groupName);
                    userSignerSignGroup.setSignerDetails(signerDetail);
                    UserSignerSignGroup responseFromSave;
                    try {
                         responseFromSave = userSignerRepository.save(userSignerSignGroup);
                    } catch (Exception ex) {
                    	throw new UnableToSaveOrUpdateOrder((String.valueOf(signerDetail.getGroupName()) + 
                    			". order already assigned to other signer"));
                    }

                    if(responseFromSave == null) {
                        throw new UnableToSaveOrUpdateOrder(String.valueOf(signerDetail.getGroupName()));
                    }
                }
            }

        }

	/**
	 * Check if the logged in user is master User or not.
	 * @param loggedInUserID
	 */
	private void checkLoggedInUserIsAuthorized(String loggedInUserID) {
		Iterable<LogginUserDetailsTable> masterData = logginSignerRepositiory.findAll();
		boolean isMasterData= false;
		for (LogginUserDetailsTable logginUserDetailsTable : masterData) {
		    if(loggedInUserID.equals(logginUserDetailsTable.getUsername())) {
		        isMasterData = true;
		      }
		}
		if(!isMasterData) {
		    throw new UserNotAuthorized("User " + loggedInUserID + " is not authorized!");
		}
	}
    
    /**
     * Check if the order is assigned to other user of the same group.
     * @param groupName.
     * @param signerDetailsList.
     */
    private void checkDuplicateOrder(
            int groupName, List<SignerDetailsJson> signerDetailsList) {
    	HashSet<Integer> hashSet = new HashSet<>();
        List<SignerDetailsJson> details = findSignerDetailsFromGroup(groupName);
        if(!details.isEmpty()) {
        	int totalNoOfSigner = details.size();
        	if(totalNoOfSigner != signerDetailsList.size()) {
        		throw new UnableToSaveOrUpdateOrder("All signer details required");
        	}
            for (SignerDetailsJson signerDetailRequest : signerDetailsList) {
            	if(signerDetailRequest.getSignerOrder() > totalNoOfSigner) {
            		throw new UnableToSaveOrUpdateOrder(
            				"Cannot give order greater than total no. of signer . Please chnage the order of signer " + totalNoOfSigner
            				+ signerDetailRequest.getSignerName());
            	}
            	if(!hashSet.add(signerDetailRequest.getSignerOrder())){
            		throw new UnableToSaveOrUpdateOrder("Duplicate Signer Order.");
            	}
            		
            }
        }
    }
            	
    
    /**
     * Method to add dummy data to signer table.
     */
    private void addDumyDataToSignerTable() {
        LogginUserDetailsTable logginUsers1 = new LogginUserDetailsTable() ;
        logginUsers1.setUsername("admin1");
        LogginUserDetailsTable logginUsers2 = new LogginUserDetailsTable() ;
        logginUsers2.setUsername("admin2");
        LogginUserDetailsTable logginUsers3 = new LogginUserDetailsTable() ;
        logginUsers3.setUsername("admin3");
        LogginUserDetailsTable logginUsers4 = new LogginUserDetailsTable() ;
        logginUsers4.setUsername("admin4");
        LogginUserDetailsTable logginUsers5 = new LogginUserDetailsTable() ;
        logginUsers5.setUsername("admin5");
        
        logginSignerRepositiory.save(logginUsers1);
        logginSignerRepositiory.save(logginUsers2);
        logginSignerRepositiory.save(logginUsers3);
        logginSignerRepositiory.save(logginUsers4);
        logginSignerRepositiory.save(logginUsers5);
    }
    
    @Override
    public void saveSignerDetails(String loggedInUserID, UserSignerDispositionSign dispositionSign) {
    	if(loggedInUserID != null )
    	{
    		checkLoggedInUserIsAuthorized(loggedInUserID);
    		
    	}
    		userSignerDispositionSignRepositiory.save(dispositionSign);

    }
    
    @Override
    public String validateSignatureOrder(String signerName, int groupName, Integer order) {
    	boolean validateSigner = false;
    	String signerDeatils = "";
    	if(order == 1) {
    		return "Valid Signer!";
    	}
    	Iterable<UserSignerDispositionSign> userSignerDispositionSignTableData = userSignerDispositionSignRepositiory.findAll();
    	for (UserSignerDispositionSign userSignerDispositionSign : userSignerDispositionSignTableData) {
    		if(userSignerDispositionSign.getSignerGroup() == groupName && userSignerDispositionSign.getIndexOrder() == (order--)) {
    			validateSigner = true;
    			break;
    		}
    		else if(userSignerDispositionSign.getSignerGroup() == groupName && userSignerDispositionSign.getIndexOrder() != (order)){
    			signerDeatils = userSignerDispositionSign.getUserSigner() + " has Signed";
    		}
		}
    	if(validateSigner) {
    		return "Valid Signer!";
    	}
        return signerDeatils;
    }
    
    @Override
    public List<SignerDetailsJson> getSignerOrderForGroup(int groupName) {
        List<SignerDetailsJson> signerDetails1;
        signerDetails1 = findSignerDetailsFromGroup(groupName);

        if(signerDetails1.isEmpty()) {
            throw new GroupNotFound("Group Not Found");
        }
        return signerDetails1;
    }
    
    /**
     * Find details of Signer From Group.
     * @param groupName.
     * @return List of Signer Details for the group.
     */
    private List<SignerDetailsJson> findSignerDetailsFromGroup(int groupName) {
        List<SignerDetailsJson> signerDetails1 = new ArrayList<>(); 
        List<UserSignerSignGroup> userSignerSignGroup = (List<UserSignerSignGroup>) userSignerRepository.findAll();
        System.out.println(userSignerSignGroup.size());

        for (UserSignerSignGroup userSignerSignGroup1 : userSignerSignGroup) {
            if(userSignerSignGroup1.getSignerDetails().getGroupName() == groupName) {
                SignerDetailsJson detailsJson = new SignerDetailsJson();
                detailsJson.setSignerName(userSignerSignGroup1.getSignerDetails().getSignerName());
                detailsJson.setSignerOrder(userSignerSignGroup1.getSignerOrder());
                signerDetails1.add(detailsJson);
            }
        }
        return signerDetails1;
    }

    @PostConstruct
    protected void init() {
    	addDumyDataToSignerTable();
    }
}
