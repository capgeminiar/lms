package it.nexi.digitalfactory.user.api.domain;

import java.util.List;

import lombok.Data;

@Data
public class UserSignerSignGroupJson {


	public UserSignerSignGroupJson() {

    }
	private String loginSignerName; 
    private Long id;

    
    private int groupName;

    private List<SignerDetailsJson> signerDetails;


}
