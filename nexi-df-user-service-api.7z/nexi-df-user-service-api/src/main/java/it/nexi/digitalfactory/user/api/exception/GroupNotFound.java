package it.nexi.digitalfactory.user.api.exception;

public class GroupNotFound extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2724488235306684648L;
	
	public GroupNotFound(String exception) {
		super(exception);
	}

}
