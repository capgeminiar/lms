package it.nexi.digitalfactory.user.api.exception;

public class GroupNameAlreadyExistsException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2724488235306684648L;
	
	public GroupNameAlreadyExistsException(String exception) {
		super(exception);
	}

}
