package it.nexi.digitalfactory.user.api.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import it.nexi.digitalfactory.user.api.domain.SignerDetails;
import it.nexi.digitalfactory.user.api.domain.UserSignerSignGroup;

@Repository
public interface UserSignerRepository extends CrudRepository<UserSignerSignGroup, Long> {
	
}
