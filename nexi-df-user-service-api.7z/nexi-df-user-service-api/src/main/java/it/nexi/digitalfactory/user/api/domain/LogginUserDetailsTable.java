package it.nexi.digitalfactory.user.api.domain;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table
@Data
public class LogginUserDetailsTable implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public LogginUserDetailsTable() {
		
	}
	
	@Id
	public  String username;
	public String password;
	
	
}
