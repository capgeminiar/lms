package it.nexi.digitalfactory.user.api.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import it.nexi.digitalfactory.user.api.domain.UserSignerDispositionSign;

@Repository
public interface UserSignerDispositionSignRepositiory extends CrudRepository<UserSignerDispositionSign, Long> {
	
}
