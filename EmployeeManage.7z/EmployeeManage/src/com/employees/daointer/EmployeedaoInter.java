package com.employees.daointer;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.employees.Exception.FirstException;
import com.employees.dao.EmployeeDao;
import com.employees.pojo.Employee;
import com.employees.pojo.Status;


@Repository
@Transactional
public class EmployeedaoInter implements EmployeeDao {
	
	@Autowired
	@PersistenceContext
	private EntityManager entitymanager ;
     
	private static final Logger logger=Logger.getLogger(EmployeedaoInter.class);

	
	@Override
	public Employee loginPage(String username, String password) {
		
		logger.info("inside login dao layer");
		 Employee employee=null;
		String str="select e from Employee e where e.empusername=:userName and e.emppassword=:password";
		Query query=this.entitymanager.createQuery(str);
		try{
		  employee=(Employee)query.setParameter("userName",username).setParameter("password",password).getSingleResult();
		}
		catch(NoResultException ex)
		 {
			logger.warn("Please enter correct username & password");
		    throw new FirstException();
		 }
		 return employee;
		
	}

	@Override
	public boolean addEmployee(Employee employee) {
		logger.info("inside save employee record dao layer");
		if(employee!=null)
		{
		  this.entitymanager.persist(employee);
		  this.entitymanager.flush();
		  logger.info("Employee data is successfully saved.");
		  return true;
		}
		else
			logger.warn("Employee data is not saved.");
			return false;
		
	}

	@Override
	public int updateEmployee(Employee employee) {
		logger.info("inside update dao layer of employee:"+ employee.getEmpname());
		this.entitymanager.merge(employee);
		this.entitymanager.flush();
		return employee.getEmpid();
		
	}

	@Override
	public Employee getEmployeeById(int id) {
	  logger.info("inside getemployeeby id :"+ id);
		String str="select e from Employee e where e.empid=:empid";
		Query query=this.entitymanager.createQuery(str);
		Employee emp=(Employee)query.setParameter("empid",id).getSingleResult();
		return emp;
	}

	@Override
	public boolean removeEmployee(int id) {
		logger.info("inside delete record dao layer.");
		int value=this.getDeleteChild(id);
 if(value>0)
		{
		   String deletestring="delete from Employee e where e.empid=:id";
		  Query query=this.entitymanager.createQuery(deletestring);
		  int result=query.setParameter("id",id).executeUpdate();
		  if(result>0)
		      {
			    logger.info("inside after record is deleted in dao layer");
		        return true;
		      }
		  else
		    {
			   logger.warn("inside record is not deleted in dao layer");
			   return false;
		    }
		}
		  else
			   logger.warn("employee id is not found.");
			   return false;
		
	}
	
	
	public int getDeleteChild(int empid)
	{
		System.out.println("inside child delete record.");
		String childdelete="delete from Status s where s.employee.empid=:id";
		int value=this.entitymanager.createQuery(childdelete).setParameter("id",empid).executeUpdate();
		return value;
	}

	@Override
	public List<Employee> listEmployees() {
		System.out.println("inside list dao.");
		String str1="select e from Employee e";
		   Query query=this.entitymanager.createQuery(str1);
		   List<Employee> list=query.getResultList();
		   return list;
	}

	@Override
	public boolean fillStatus(Status status) {
		System.out.println("inside fillstatus list.");
		System.out.println(status.toString());
		this.entitymanager.persist(status);
		this.entitymanager.flush();
		return true;
	}

	@Override
	public boolean changePassword(String password,String perviouspassword) {
		System.out.println("inside change password dao.");
		String changepassword="update Employee e set e.emppassword=:password where e.emppassword=:perviouspassword";
		Query query=this.entitymanager.createQuery(changepassword);
		query.setParameter("password",password).setParameter("perviouspassword",perviouspassword);
		int result=query.executeUpdate();
		if(result>0)
		return true;
		else
			return false;
	}

	@Override
	public List<Status> getEmployeeStatus(int empid) {
		System.out.println("inside employee dao.");
		
		String fetchquery="select u from Status u where u.employee.empid=:id";
		Query fetch=this.entitymanager.createQuery(fetchquery).setParameter("id",empid);
		List<Status> list=fetch.getResultList();
		return list;
	}
	@Override
	public Status updateStatus(int id) {
		System.out.println("inside updatestatus."+ id);
		String updatestatusid="select o from Status o where o.statusid=:id";
		Query query=this.entitymanager.createQuery(updatestatusid).setParameter("id",id);
		Status staus=(Status)query.getSingleResult();
		return staus;
	}

	@Override
	public int updateStatus(Status status) {
		System.out.println("inside update staus dao." + status.getStatusid() + status.getDate() + status.getEmpstatus());
		status.setDate(Calendar.getInstance().getTime());
		System.out.println("inside update staus dao." + status.getStatusid() + status.getDate() + status.getEmpstatus());
		int statusId=status.getStatusid();
		String upadtestatus="update Status e set e.empstatus=:empstatus,e.date=:date where e.statusid=:statusId";
		Query updatequery=this.entitymanager.createQuery(upadtestatus).setParameter("empstatus",status.getEmpstatus()).setParameter("date",status.getDate()).setParameter("statusId",statusId);
		int number=updatequery.executeUpdate();
		return number;
		
	}

	@Override
	public List<Object[]> listStatus() {
		
		System.out.println("inside fetch status.");
		String fetchstatus="select s.statusid,e.empname,e.empmobile,s.empstatus,s.date from Status s,Employee e where s.employee.empid=e.empid";
		List<Object[]> obj=this.entitymanager.createQuery(fetchstatus).getResultList();
		return obj;
	}

	@Override
	public List<Date> getDatetime(int id) {
		System.out.println("inside time and date dao.");
		String datetime="select u.date from Status u where u.employee.empid=:empid";
		List<Date> list=this.entitymanager.createQuery(datetime).setParameter("empid",id).getResultList();
		return list;
	}

	@Override
	public String getStatus(Date date) {
		System.out.println("inside got status "+ date);
		String gotstatus="select u.empstatus from Status u where u.date=:datetime";
		String statusresult=(String)this.entitymanager.createQuery(gotstatus).setParameter("datetime",date).getSingleResult();
		return statusresult;
	}

	

	
}
