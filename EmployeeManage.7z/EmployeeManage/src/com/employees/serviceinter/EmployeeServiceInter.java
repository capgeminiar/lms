package com.employees.serviceinter;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employees.Exception.FirstException;
import com.employees.dao.EmployeeDao;
import com.employees.pojo.Employee;
import com.employees.pojo.Status;
import com.employees.service.EmployeeService;

@Service
public class EmployeeServiceInter implements EmployeeService {
	
	@Autowired
	private EmployeeDao employeedao;

	@Override
	public int updateEmployee(Employee employee) {
		
		return this.employeedao.updateEmployee(employee);
	}

	@Override
	public Employee getEmployeeById(int id) {
		
		return this.employeedao.getEmployeeById(id);
	}

	@Override
	public boolean removeEmployee(int id) {
		
		return this.employeedao.removeEmployee(id);
	}

	@Override
	public List<Employee> listEmployees() {
		System.out.println("inside lit service.");
		return this.employeedao.listEmployees();
	}

	@Override
	public Employee loginPage(String username, String password) {
		
		return this.employeedao.loginPage(username, password);
	}

	@Override
	public boolean addEmployee(Employee employee) {
		System.out.println("inside registration service.");
		return this.employeedao.addEmployee(employee);
	}

	@Override
	public boolean fillStatus(Status status) {
		return this.employeedao.fillStatus(status);
	}

	@Override
	public boolean changePassword(String password,String perviouspassword) {
		return this.employeedao.changePassword(password,perviouspassword);
	}

	@Override
	public List<Status> getEmployeeStatus(int empid) {
		
		return this.employeedao.getEmployeeStatus(empid);
	}

	@Override
	public Status updateStatus(int id) {
		
		return this.employeedao.updateStatus(id);
	}

	@Override
	public int updateStatus(Status status) {
		
		return this.employeedao.updateStatus(status);
	}

	@Override
	public List<Object[]> listStatus() {
		
		return this.employeedao.listStatus();
	}

	@Override
	public List<Date> getDatetime(int id) {
		
		return this.employeedao.getDatetime(id);
	}

	@Override
	public String getStatus(Date date) {
		
		return this.employeedao.getStatus(date);
	}

	

	

}
