package com.employees.Exception;

import org.springframework.web.servlet.ModelAndView;

public class FirstException extends RuntimeException {
	
	private String name;
	
	public FirstException()
	{
		name="error";
	}

	
	public String getPage()
	{
		return this.name;
	}
	
	@Override
	public String getMessage()
	{
		return "invalid credentails.";
	}
}
