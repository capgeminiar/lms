package com.employees.Exception;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;


@ControllerAdvice
public class MyException {
	
	@ExceptionHandler(FirstException.class)
	public ModelAndView  processCustomException(FirstException ceh,Exception ex)
	{
		ModelAndView mav = new ModelAndView("error");
		System.out.println("inside erroe");
		mav.addObject("failure", ceh.getMessage());
	    return mav;
	}	



}
