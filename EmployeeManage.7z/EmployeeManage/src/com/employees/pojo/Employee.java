package com.employees.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Entity
@Table(name="EmployeeManagers")
public class Employee  {

	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", empname=" + empname
				+ ", empmobile=" + empmobile + ", empusername=" + empusername
				+ ", emppassword=" + emppassword + "]";
	}

	private int empid;
	private String empname;
	private String empmobile;
	private String empusername;
	private String emppassword;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO,generator="EMPLOYEEMANAGERS_SEQ")
	@SequenceGenerator(name="EMPLOYEEMANAGERS_SEQ",allocationSize=1,sequenceName="EMPLOYEEMANAGERS_SEQ")
	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	@Column(name = "employeename", updatable = true, nullable = false)
	@Size(max=25,min=0,message="Employee name should be less than 25")
	@Pattern(regexp="^[\\p{L} .'-]+$",message="Employee name should have only characters.")
	public String getEmpname() {
		return empname;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}

	@Column(name = "employeemobileno", updatable = true, nullable = false, unique = true)
	@Size(max = 10, min = 10,message="Employee mobile number should be equal to 10")
	@Pattern(regexp="^[7-9][0-9]{9}$",message="Mobile no should start with 7 or 9")
	public String getEmpmobile() {
		return empmobile;
	}

	public void setEmpmobile(String empmobile) {
		this.empmobile = empmobile;
	}

	@Column(name = "employeeusername", unique = true, nullable = false, updatable = true)
	@Size(max = 7, min = 3,message="Employee username should be greater than 3 and less than equal to 7")
	@Pattern(regexp="(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{3,}",message="Employee username should have at least one Capital letter,one small letter,one special letter,one digit")
	public String getEmpusername() {
		return empusername;
	}

	public void setEmpusername(String empusername) {
		this.empusername = empusername;
	}

	@Column(name = "employeepassword", unique = true, nullable = false, updatable = true)
	@Size(max = 6, min = 3,message="Employee password should be greater than 3 and less than 6")
	@Pattern(regexp="(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{3,}",message="Employee password should have at least one Capital letter,one small letter,one special letter,one digit")
	public String getEmppassword() {
		return emppassword;
	}

	public void setEmppassword(String emppassword) {
		this.emppassword = emppassword;
	}

	

}
