package com.employees.pojo;



import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="EmployeeStatus")
public class Status {
	
	private int statusid;
	private String empstatus;
	private Employee employee;
	private Date date;
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO,generator="EMPLOYEESTATUS_SEQ")
	@SequenceGenerator(name="EMPLOYEESTATUS_SEQ",allocationSize=1,sequenceName="EMPLOYEESTATUS_SEQ")
	public int getStatusid() {
		return statusid;
	}
	public void setStatusid(int statusid) {
		this.statusid = statusid;
	}
	
	@Column(name="empstatus",length=10,updatable=true,nullable=false)
	public String getEmpstatus() {
		return empstatus;
	}
	public void setEmpstatus(String empstatus) {
		this.empstatus = empstatus;
	}
	
	@ManyToOne(optional=false,cascade={CascadeType.REMOVE,CascadeType.REFRESH,CascadeType.MERGE},fetch=FetchType.EAGER)
	@JoinColumn(name="empstatusid",nullable=false,referencedColumnName="empid")
	public Employee getEmployee() {
		return employee;
	}
	@Override
	public String toString() {
		return "Status [statusid=" + statusid + ", empstatus=" + empstatus
				+ ", employee=" + employee + ", date=" + date + "]";
	}
	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	
	
	@Column(name="empdate",updatable=true,nullable=false,length=30)
	@Temporal(TemporalType.TIMESTAMP)
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	
	

}
