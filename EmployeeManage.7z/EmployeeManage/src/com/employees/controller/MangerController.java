package com.employees.controller;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.employees.pojo.Employee;
import com.employees.pojo.Status;
import com.employees.service.EmployeeService;


@Controller
public class MangerController {
	@Autowired
	private EmployeeService employeeservice;
	
	@RequestMapping(value="/fetchallstatus",method=RequestMethod.GET)
	public String getAllStatus(Model model)
	{
		System.out.println("inside fecth status.");
		List<Object []> obj=this.employeeservice.listStatus();
		model.addAttribute("statuslist",obj);
		model.addAttribute("message","STATUS LIST OF EMPLOYEE");
		return "Adminwelcome";
	}
	
	@RequestMapping(value="/getexcel")
	public ModelAndView getExcelFile(ModelAndView views)
	{
		System.out.println("inside pdf generator.");
		List<Object []> obj=this.employeeservice.listStatus();
	    return new ModelAndView(new StatusExcelView(),"statusList",obj);
	}

	@RequestMapping(value="/updatehisrecord",method=RequestMethod.GET)
	public String updateHisRecord(Model model,HttpSession session)
	{
		System.out.println("inside update his record.");
		Employee employee=(Employee)session.getAttribute("employee");
		Employee emp=this.employeeservice.getEmployeeById(employee.getEmpid());
		String s=employee.getEmpname().toUpperCase();
		Employee e=new Employee();
		model.addAttribute("updatemessage","YOU CAN UPDATE YOUR RECORD MR."+s);
		model.addAttribute("employee",emp);
		model.addAttribute("em", e);
		return "employee";
	}
	
	@RequestMapping(value="/afterupdatehisrecord",method=RequestMethod.POST)
	public String afterUpdateHisRecord(@ModelAttribute("em") Employee employee,Model model)
	{
		System.out.println("inside after update record.");
		int updaterecord=this.employeeservice.updateEmployee(employee);
		if(updaterecord>0)
		{
			model.addAttribute("updaterecord","You have successfully updated record.");
			return "employee";
		}
		else
		{
			model.addAttribute("failurerecord","Your record is not found.");
			return "employee";
		}
		
	}
	
	@RequestMapping(value="/getDatetime/{empid}",method=RequestMethod.GET)
	public String getDateTime(@PathVariable Integer empid,Model model)
	{
		System.out.println("inside getdatetime"+ empid);
		List<Date> list=this.employeeservice.getDatetime(empid);
		System.out.println("size:"+ list.size());
		model.addAttribute("timemess","Select datetime to see status.");
		model.addAttribute("timelist",list);
		return "Adminwelcome";
	}
	
	@RequestMapping(value="/aftergottimedate",method=RequestMethod.GET)
	public String afterGotTime(@RequestParam(value="datetime")  @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss.SSS ") Date datetime,Model model)
	{
		System.out.println("inside datetime got."+ datetime);
		
		String statusresult=this.employeeservice.getStatus(datetime);
		model.addAttribute("successtime", "YOUR STATUS FOR GIVEN DATE & TIME:" +datetime);
		model.addAttribute("status",statusresult);
		return "Adminwelcome";
	
		
	}
}
