package com.example.practice.Donor.service;

import java.util.List;

import com.example.practice.Donor.bean.Donor;
import com.example.practice.Donor.exception.DonorException;



public interface IDonorService {
	public void addDonorDetails(Donor donor) throws DonorException;
	public Donor viewDonorDetails(Long donorId) throws DonorException;
	public List<Donor> retriveAll()throws DonorException;

}
