package com.example.practice.Donor.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


import com.example.practice.Donor.bean.Donor;
import com.example.practice.Donor.exception.DonorException;

public interface IDonorDao extends JpaRepository<Donor, Long>{
	

}
