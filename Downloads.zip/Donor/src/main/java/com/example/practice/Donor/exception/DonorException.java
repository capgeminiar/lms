package com.example.practice.Donor.exception;

public class DonorException extends RuntimeException{
	public DonorException(String exception) {
	    super(exception);
	  }

}
