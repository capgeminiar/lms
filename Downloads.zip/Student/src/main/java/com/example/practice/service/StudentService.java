package com.example.practice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.practice.dao.IStudentDao;
import com.example.practice.entity.Student;
@Service
public class StudentService implements IStudentService{
	@Autowired
	private IStudentDao dao;

	@Override
	public List<Student> getAllUsers() {
		// TODO Auto-generated method stub
		return dao.getAllUsers();
	}

	@Override
	public Student getStudentById(String rollNo) {
		// TODO Auto-generated method stub
		return dao.getStudentById(rollNo);
	}

	@Override
	public Student addNewStudent(Student student) {
		// TODO Auto-generated method stub
		return dao.addNewStudent(student);
	}

	@Override
	public Student deleteStudent(String rollNo) {
		// TODO Auto-generated method stub
		return dao.deleteStudent(rollNo);
	}

}
