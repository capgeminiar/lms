package com.cg.tds.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.NOT_FOUND)
public class TdsIdNotFoundException extends RuntimeException{
	public TdsIdNotFoundException(String exception)
	{
		super(exception);
	}

}
