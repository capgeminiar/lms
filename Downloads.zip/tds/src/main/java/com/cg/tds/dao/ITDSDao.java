package com.cg.tds.dao;

import java.util.List;

import com.cg.tds.entity.Tdsdetail;



public interface ITDSDao {
	public Tdsdetail getDetailsById(String unique_id);
	List<Tdsdetail> getAll();
	

}
