package com.cg.tds.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Tdsdetail {
	
	private String unique_id;
	private String deductor_name;
	private String deductor_pan;
	private int tds_deposited;
	
	public String getUnique_id() {
		return unique_id;
	}
	public void setUnique_id(String unique_id) {
		this.unique_id = unique_id;
	}
	public String getDeductor_name() {
		return deductor_name;
	}
	public void setDeductor_name(String deductor_name) {
		this.deductor_name = deductor_name;
	}
	public String getDeductor_pan() {
		return deductor_pan;
	}
	public void setDeductor_pan(String deductor_pan) {
		this.deductor_pan = deductor_pan;
	}
	public int getTds_deposited() {
		return tds_deposited;
	}
	public void setTds_deposited(int tds_deposited) {
		this.tds_deposited = tds_deposited;
	}

	

}
