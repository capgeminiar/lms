package com.cg.tds.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.tds.dao.ITDSDao;
import com.cg.tds.entity.Tdsdetail;
@Service
public class TDSService implements ITDSService{
	@Autowired
	private ITDSDao dao;
	public Tdsdetail getDetailsById(String unique_id) {
		return dao.getDetailsById(unique_id);
	}
	@Override
	public List<Tdsdetail> getAll() {
		// TODO Auto-generated method stub
		return dao.getAll();
	}
	
}
