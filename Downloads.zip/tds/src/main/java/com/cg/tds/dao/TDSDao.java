package com.cg.tds.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.cg.tds.entity.Tdsdetail;



@Repository
public class TDSDao implements ITDSDao{
	@Autowired
	private MongoTemplate mongoTemplate;
	/************************
	 * ****************************************************************
	 * @param unique_id
	 * @return tds detail class
	 * throws - tdsnotfound exception
	 * author - Capgemini
	 * creationdate - 23/08/2018
	 * This method maps the user request and gets the details as per unique id
	 ******************************************************************/
	@Override
	public Tdsdetail getDetailsById(String unique_id) {
		Query query = new Query();
		query.addCriteria(Criteria.where("unique_id").is(unique_id));
		return mongoTemplate.findOne(query, Tdsdetail.class);
	}

	@Override
	public List<Tdsdetail> getAll() {
		return mongoTemplate.findAll(Tdsdetail.class);
	}

	

}
