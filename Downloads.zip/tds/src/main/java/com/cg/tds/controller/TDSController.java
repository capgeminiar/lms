package com.cg.tds.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.cg.tds.entity.Tdsdetail;
import com.cg.tds.exception.TdsIdNotFoundException;
import com.cg.tds.service.ITDSService;



@RestController
@RequestMapping(value = "/")
public class TDSController {
	@Autowired
	private ITDSService service;
	/************************
	 * *************
	 * @param unique_id
	 * @return tds detail class
	 * This method maps the user request and gets the details as per unique id
	 */
	@RequestMapping(value = "/{unique_id}", method = RequestMethod.GET)
	public Tdsdetail getUser(@PathVariable String unique_id) {
		
		Tdsdetail  tds = service.getDetailsById(unique_id);
	    if( tds == null)
	    {
	    	throw new TdsIdNotFoundException(" ID Not found wrong ID : "+unique_id);
	    }
	    
	    return tds;
	}
	@RequestMapping(value = "", method = RequestMethod.GET)
	public List<Tdsdetail> getAllUsers() {
		
		return service.getAll();
	}
	

}
