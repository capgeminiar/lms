package com.cg.tds.service;

import java.util.List;

import com.cg.tds.entity.Tdsdetail;


public interface ITDSService {
	public Tdsdetail getDetailsById(String unique_id);
	public List<Tdsdetail> getAll();


}
