package com.cg.expense.expense.exception;

public class EmployeeException extends RuntimeException{
	public EmployeeException(String exception) {
	    super(exception);
	  }

}
