package com.example.practice.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.example.practice.entity.Student;
@Repository
public class StudentDao implements IStudentDao{
	
	@Autowired
	private MongoTemplate mongoTemplate;

	@Override
	public List<Student> getAllUsers() {
		// TODO Auto-generated method stub
		return mongoTemplate.findAll(Student.class);
	}

	@Override
	public Student getStudentById(String rollNo) {
		Query query = new Query();
		query.addCriteria(Criteria.where("rollNo").is(rollNo));
		return mongoTemplate.findOne(query, Student.class);
	}

	@Override
	public Student addNewStudent(Student student) {
		mongoTemplate.save(student);
		return student;
	}

	@Override
	public Student deleteStudent(String rollNo) {
		Student student=getStudentById(rollNo);
		if(student!=null)
		{
			mongoTemplate.remove(student);
		}
		return student;
	}

}
