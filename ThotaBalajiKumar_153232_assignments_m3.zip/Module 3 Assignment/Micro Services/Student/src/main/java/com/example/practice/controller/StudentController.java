package com.example.practice.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.practice.entity.Student;
import com.example.practice.exception.StudentNotFoundException;
import com.example.practice.service.IStudentService;

@RestController
@RequestMapping(value = "/")
public class StudentController {
	@Autowired
	private IStudentService service;
	
	
	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public Student addStudent(@Valid @RequestBody Student student)
	{
		HashMap<String,String> cp = new HashMap<String,String>();
		cp.put("Banglore","Karnataka");
		cp.put("Pune", "Maharastra");
		cp.put("Mumbai", "Maharastra");
		cp.put("bangalore","Karnataka");
		cp.put("pune", "Maharastra");
		cp.put("mumbai", "Maharastra");
		
			if(cp.containsKey(student.getCity()))
			{
				student.setState(cp.get(student.getCity()));
			}
			else
				student.setState("NA");
	
		return service.addNewStudent(student);
	}
	
	@RequestMapping(value = "/{rollNo}", method = RequestMethod.DELETE)
	public Student delete(@PathVariable String rollNo) {
		return service.deleteStudent(rollNo);
	}
	@RequestMapping(value = "", method = RequestMethod.GET)
	public List<Student> getAllUsers() {
		
		return service.getAllUsers();
	}
	@RequestMapping(value = "/{rollNo}", method = RequestMethod.GET)
	public Student getUser(@PathVariable String rollNo) {
		
		Student  stu = service.getStudentById(rollNo);
	    if( stu == null)
	    {
	    	throw new StudentNotFoundException(" User Not Found ");
	    }
	    
	    return stu;
	}


}
