package com.example.practice.dao;

import java.util.List;

import com.example.practice.entity.Student;

public interface IStudentDao {
	List<Student> getAllUsers();

	Student getStudentById(String rollNo);

	Student addNewStudent(Student student);
	
	Student  deleteStudent(String rollNo) ;

}
