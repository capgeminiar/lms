package com.example.practice.service;

import java.util.List;

import com.example.practice.entity.Student;



public interface IStudentService {
	List<Student> getAllUsers();

	Student getStudentById(String rollNo);

	Student addNewStudent(Student student);
	
	Student  deleteStudent(String rollNo) ;

	

}
