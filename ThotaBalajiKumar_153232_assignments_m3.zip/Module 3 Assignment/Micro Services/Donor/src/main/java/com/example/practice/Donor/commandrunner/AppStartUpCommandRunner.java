package com.example.practice.Donor.commandrunner;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;


import com.example.practice.Donor.bean.Donor;
import com.example.practice.Donor.service.IDonorService;

@Component
public class AppStartUpCommandRunner implements CommandLineRunner {

	@Autowired
	IDonorService service;
	
	@Override
	public void run(String... args) throws Exception {
		Donor d1 = new Donor();
		d1.setDonorName("maddy");
		d1.setPhoneNumber("9999999999");
		d1.setDonationDate("12/12/2012");
		d1.setDonationAmount(15000);
		d1.setAddress("pune");
		Donor d2 = new Donor();
		d2.setDonorName("maddy");
		d2.setPhoneNumber("9999999999");
		d2.setDonationDate("12-12-2012");
		d2.setDonationAmount(15000);
		d2.setAddress("pune");
		
		service.addDonorDetails(d1);
		service.addDonorDetails(d2);
		List<Donor> customers = service.retriveAll();
		for (Donor customer : customers) {
			System.out.println(customer.getDonorName());
		}
		
		
	}

}
