package com.example.practice.Donor.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.example.practice.Donor.bean.Donor;
import com.example.practice.Donor.dao.IDonorDao;
import com.example.practice.Donor.exception.DonorException;
@Service
public class DonorService implements IDonorService{
	@Autowired IDonorDao dao;

	@Override
	public void addDonorDetails(Donor donor) throws DonorException {
		// TODO Auto-generated method stub
		dao.save(donor);
		
	}

	@Override
	public Donor viewDonorDetails(Long donorId) throws DonorException {
		// TODO Auto-generated method stub
		return dao.findById(donorId).get();
		
	}

	@Override
	public List<Donor> retriveAll() throws DonorException {
		List<Donor> donor = new ArrayList<>();
		for (Donor don : dao.findAll()) {
			donor.add(don);
		}
		return donor;
	
	}

	

	

}
