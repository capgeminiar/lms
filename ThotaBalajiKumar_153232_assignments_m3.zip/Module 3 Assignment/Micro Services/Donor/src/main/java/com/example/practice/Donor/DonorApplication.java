package com.example.practice.Donor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.example.practice.Donor")
public class DonorApplication {

	public static void main(String[] args) {
		SpringApplication.run(DonorApplication.class, args);
	}
}
