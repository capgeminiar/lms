package com.appsone.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="binding")
public class Binding {
	
	@Id
   	@Column(name ="BINDINGID")
	private int bindingId;
	
	@Column(name ="BINDINGNAME")
	private String bindingName;
	
	public int getBindingId() {
		return bindingId;
	}
	public void setBindingId(int bindingId) {
		this.bindingId = bindingId;
	}
	public String getBindingName() {
		return bindingName;
	}
	public void setBindingName(String bindingName) {
		this.bindingName = bindingName;
	}
	
	@Override
	public String toString() {
		return "Binding [bindingId=" + bindingId + ", bindingName=" + bindingName + "]";
	}
	
	public Binding() {
		super();
	}

	public Binding(int bindingId, String bindingName) {
		super();
		this.bindingId = bindingId;
		this.bindingName = bindingName;
	}
}
