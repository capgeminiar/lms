package com.appsone.bean;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name ="BOOKSFORAPPROVAL")
public class Booksforapproval {
	
	@Id
	@GeneratedValue
	@Column(name = "AppId")
	private int appId;
	
	@ManyToOne/*(cascade = CascadeType.ALL)*/
	@JoinColumn(name="BOOKID") //, nullable=false, insertable = false, updatable = false)
	private Book book2;
	
   	@Column(name = "BOOKCODE")
	private String bookcode;

   	@Column(name = "BOOKTITLE")
	private String bookTitle;

   	@Column(name = "AUTHOR")
	private String author;
   	
   	@Column(name = "BINDINGID")
	private int bindingId;
   	
   	@Column(name = "CATEGORYID")
	private int categoryId;
   	
   	@Column(name = "PUBLICATIONYEAR")
	private int publicationYear;
   	
   	@Column(name = "BOOKPRICE")
	private int bookPrice;
   	
   	@Column(name = "BOOKEDITION")
	private String bookEdition;
   	
   	@Column(name="ISACTIVE")
   	private String isactive;
	
   	@ManyToOne/*(cascade = CascadeType.ALL)*/
	@JoinColumn(name="MEMBERID") //, nullable=false, insertable = false, updatable = false)
   	private Member member2;
   	
   	@Column(name = "Reqdate")
   	private Date reqdate;
	
   	
	public int getAppId() {
		return appId;
	}

	public void setAppId(int appId) {
		this.appId = appId;
	}

	public Book getBook() {
		return book2;
	}

	public void setBook(Book book) {
		this.book2 = book;
	}

	public String getBookcode() {
		return bookcode;
	}

	public void setBookcode(String bookcode) {
		this.bookcode = bookcode;
	}

	public String getBookTitle() {
		return bookTitle;
	}

	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public int getBindingId() {
		return bindingId;
	}

	public void setBindingId(int bindingId) {
		this.bindingId = bindingId;
	}

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public int getPublicationYear() {
		return publicationYear;
	}

	public void setPublicationYear(int publicationYear) {
		this.publicationYear = publicationYear;
	}

	public int getBookPrice() {
		return bookPrice;
	}

	public void setBookPrice(int bookPrice) {
		this.bookPrice = bookPrice;
	}

	public String getBookEdition() {
		return bookEdition;
	}

	public void setBookEdition(String bookEdition) {
		this.bookEdition = bookEdition;
	}

	public String getIsactive() {
		return isactive;
	}

	public void setIsactive(String isactive) {
		this.isactive = isactive;
	}

	public Member getMember() {
		return member2;
	}

	public void setMember(Member member) {
		this.member2 = member;
	}

	public Date getReqdate() {
		return reqdate;
	}

	public void setReqdate(Date reqdate) {
		this.reqdate = reqdate;
	}

	@Override
	public String toString() {
		return "Booksforapproval [AppId=" + appId + ", book=" + book2 + ", bookcode=" + bookcode + ", bookTitle="
				+ bookTitle + ", author=" + author + ", bindingId=" + bindingId + ", categoryId=" + categoryId
				+ ", publicationYear=" + publicationYear + ", bookPrice=" + bookPrice + ", bookEdition=" + bookEdition
				+ ", isactive=" + isactive + ", member=" + member2 + ", Reqdate=" + reqdate + "]";
	}

	public Booksforapproval() {
		super();
	}

	public Booksforapproval(int appId, Book book, String bookcode, String bookTitle, String author, int bindingId,
			int categoryId, int publicationYear, int bookPrice, String bookEdition, String isactive, Member member, Date Reqdate) {
		super();
		this.appId = appId;
		this.book2 = book;
		this.bookcode = bookcode;
		this.bookTitle = bookTitle;
		this.author = author;
		this.bindingId = bindingId;
		this.categoryId = categoryId;
		this.publicationYear = publicationYear;
		this.bookPrice = bookPrice;
		this.bookEdition = bookEdition;
		this.isactive = isactive;
		this.member2 = member;
		this.reqdate = Reqdate;
	}

	public Booksforapproval(Book book, Member member, Date f) {
		
		this.book2 = book;
		this.bookcode = book.getBookcode();
		this.bookTitle = book.getBookTitle();
		this.author = book.getAuthor();
		this.bindingId = book.getBindingId();
		this.categoryId = book.getCategoryId();
		this.publicationYear = book.getPublicationYear();
		this.bookPrice = book.getBookPrice();
		this.bookEdition = book.getBookEdition();
		this.isactive = book.getIsactive();
		this.member2 = member;
		this.reqdate = f;
	}
	
	public void BFAPersist(Book book, Member member) {
		member.getPresentMembers().add(this);
		book.getPresentBooks().add(this);
		
	}

	/*public String printBookInfo() {
		return "bookId=" + book2 + ", bookcode=" + bookcode + ", bookTitle=" + bookTitle + ", author=" + author
				+ ", publicationYear=" + publicationYear + ", bookPrice=" + bookPrice + ", bookEdition=" + bookEdition;
	}*/
}
