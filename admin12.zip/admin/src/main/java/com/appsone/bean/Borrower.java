package com.appsone.bean;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name ="BORROWERS")
public class Borrower {

	@Id
	@GeneratedValue
   	@Column(name ="BORROWERID")
	private int borrowerId;
	
	//@Column(name ="BOOKID")
	//private int bookId;
	
	@Column(name ="BORROWED_ON")
	private Date borrowedOn;
	
	@Column(name ="BORROWED_UPTO")
	private Date borrowedUpto;
	
	@Column(name ="RETURNED_DATE")
	private Date returnedDate;
	
	@Column(name ="ISSUED_BY")
	private String issuedBy;
	
	/*@Column(name ="ISSUED_TO")
	private String issuedTo;*/
	
	@Column(name = "BOOKTITLE")
	private String bookTitle;
	
	@ManyToOne
	@JoinColumn(name="ISSUED_TO", nullable=false)//, insertable = false, updatable = false)/*, nullable=false)*/
	private Member member; //setter getter include
	
	@ManyToOne
	@JoinColumn(name="BOOKID", nullable=false)//, insertable = false, updatable = false)/*, nullable=false)*/
	private Book book;
	
	public Member getMember() {
		return member;
	}

	public void setMember(Member member) {
		
		this.member = member;
	}

	public Book getBook() {
		return book;
	}

	public void setBook(Book book) {
		this.book = book;
	}

	public int getBorrowerId() {
		return borrowerId;
	}

	public void setBorrowerId(int borrowerId) {
		this.borrowerId = borrowerId;
	}

	/*public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}*/

	public Date getBorrowedOn() {
		return borrowedOn;
	}

	public void setBorrowedOn(Date borrowedOn) {
		this.borrowedOn = borrowedOn;
	}

	public Date getBorrowedUpto() {
		return borrowedUpto;
	}

	public void setBorrowedUpto(Date borrowedUpto) {
		this.borrowedUpto = borrowedUpto;
	}

	public Date getReturnedDate() {
		return returnedDate;
	}

	public void setReturnedDate(Date returnedDate) {
		this.returnedDate = returnedDate;
	}

	public String getIssuedBy() {
		return issuedBy;
	}

	public void setIssuedBy(String issuedBy) {
		this.issuedBy = issuedBy;
	}

	/*public String getIssuedTo() {
		return issuedTo;
	}

	public void setIssuedTo(String issuedTo) {
		this.issuedTo = issuedTo;
	}
*/
	public String getBookTitle() {
		return bookTitle;
	}

	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}

	@Override
	public String toString() {
		return "Borrower [borrowerId=" + borrowerId + ", bookId=" + book.getBookId() + ", borrowedOn=" + borrowedOn
				+ ", borrowedUpto=" + borrowedUpto + ", returnedDate=" + returnedDate + ", issuedBy=" + issuedBy
				+ ", issuedTo=" + member.getMemberId() + ", bookTitle=" + bookTitle + "]";
	}

	public Borrower(int borrowerId, Book bookId, Date borrowedOn, Date borrowedUpto, Date returnedDate,
			String issuedBy, Member issuedTo, String bookTitle) {
		super();
		this.borrowerId = borrowerId;
		this.book = bookId;
		this.borrowedOn = borrowedOn;
		this.borrowedUpto = borrowedUpto;
		this.returnedDate = returnedDate;
		this.issuedBy = issuedBy;
		this.member = issuedTo;
		this.bookTitle = bookTitle;
	}

	//Hibernate requires no-args constructor
	public Borrower() {
		super();
	}
	public Borrower(Book book, Member member, Date f, String librarianId) throws ParseException {
		
		//this.borrowerId = borrowerId;
		this.book = book;
		//DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		this.borrowedOn = f; /*dtf.format(f);*/
		this.borrowedUpto = getDueDate();
		this.returnedDate = null;
		this.issuedBy = librarianId;
		this.member = member;
		this.bookTitle = book.getBookTitle();
	}
	
	public Date getDueDate() throws ParseException {

        //DateFormat dtf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date duedate = this.borrowedOn; /*dtf.parse(this.borrowedOn);*/

        Calendar cal = new GregorianCalendar();
        cal.setTime(duedate);
        cal.add(Calendar.DATE, 7);

        Date dueDate = cal.getTime(); /*dtf.format(cal.getTime());*/
        // System.out.println("String new due date " + dueDate);

        return dueDate;
    }

	public void BorrowerPersist(Book book, Member member) {
		member.getCurrentMembers().add(this);
		book.getCurrentBooks().add(this);
		
	}
	
}
