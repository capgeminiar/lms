package com.appsone.bean;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name ="STATUS")
public class Status {

	@Id
	@GeneratedValue
   	@Column(name ="STATUSID")
	private int statusId;
	
	@Column(name="MEMBERID")
	private String memberId; //setter getter include

	@Column(name ="PRICE_OF_MBRSHIP")
	private int price;
	
	@Column(name ="VALIDITY")
	private String validity;
	
	@Column(name ="MBRSHIP_START_DATE")
	private Date startDate;
	
	@Column(name ="MBRSHIP_END_DATE")
	private Date endDate;
	
	public int getStatusId() {
		return statusId;
	}

	public void setStatusId(int statusId) {
		this.statusId = statusId;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getValidity() {
		return validity;
	}

	public void setValidity(String validity) {
		this.validity = validity;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	@Override
	public String toString() {
		return "Status [statusId=" + statusId + ", memberId=" + memberId + ", price=" + price + ", validity=" + validity
				+ ", startDate=" + startDate + ", endDate=" + endDate + "]";
	}

	public Status(int statusId, String memberId, int price, String validity, Date startDate, Date endDate) {
		super();
		this.statusId = statusId;
		this.memberId = memberId;
		this.price = price;
		this.validity = validity;
		this.startDate = startDate;
		this.endDate = endDate;
	}

	//Hibernate requires no-args constructor
	public Status() {
		super();
	}

	public Status(String memberId, int price, Date time) {
		
		this.memberId = memberId;
		this.price = price;
		this.validity = getValid();
		this.startDate = time;
		this.endDate = getEndingDate();
	}	
	
	public Status(int statusId, String memberId, int price, Date startDate, Date endDate) {
		
		this.statusId = statusId;
		this.memberId = memberId;
		this.price = price;
		this.validity = getValid();
		this.startDate = startDate;
		this.endDate = getEndingDate(endDate);
		
	}
	
public Date getEndingDate(Date endDate) {
		
		int price2 = this.price;
		Date date = endDate;
		Calendar cal = new GregorianCalendar();
		cal.setTime(date);
		if(price2 == 500) {
			cal.add(Calendar.MONTH, 6);
		} else if(price2 == 1000) {
			cal.add(Calendar.YEAR, 1);
		} else {
			return endDate;
		}
		return cal.getTime();
	}

	public Date getEndingDate() {
		
		int price2 = this.price;
		Date date = this.startDate;
		Calendar cal = new GregorianCalendar();
		cal.setTime(date);
		if(price2 == 500) {
			cal.add(Calendar.MONTH, 6);
		} else if(price2 == 1000) {
			cal.add(Calendar.YEAR, 1);
		} else {
			return date;
		}
		return cal.getTime();
	}
	
	public String getValid() {
		
		if(this.price == 500) {
			
			return "6 Months";
			
		} else if (this.price == 1000) {
			
			return "1 Year";
		
		} else {
			
			return "0 Days";
		}
	}
}