package com.appsone.bean;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Members")
public class Member {
	
	

	@OneToMany(mappedBy = "member", cascade = {CascadeType.ALL})
	List<Borrower> currentMembers = new ArrayList<Borrower>();
	
	
	@OneToMany(mappedBy = "member2", cascade = {CascadeType.ALL})
	List<Booksforapproval> presentMembers = new ArrayList<Booksforapproval>();
	
	public List<Booksforapproval> getPresentMembers() {
		return presentMembers;
	}

	public void setPresentMembers(List<Booksforapproval> presentMembers) {
		this.presentMembers = presentMembers;
	}

	@Id
   	@Column(name = "memberId")
	private String memberId;
	
	@Column(name="firstName")
	private String firstName;
	
	@Column(name="middleName")
	private String middleName;
	
	@Column(name="lastName")
	private String lastName;
	
	@Column(name="address")
	private String address;
	
	@Column(name="street")
	private String street;
	
	@Column(name="city")
	private String city;
	
	@Column(name="state")
	private String state;
	
	@Column(name="zipCode")
	private String zipCode;
	
	@Column(name="mobileNo")
	private String mobileNo;
	
	@Column(name="emailId")
	private String emailId;
	
	@Column(name="createdDate")
	private String createdDate;
	
	@Column(name="modifiedDate")
	private String modifiedDate;
	
	public List<Borrower> getCurrentMembers() {
		return currentMembers;
	}


	public void setCurrentMembers(List<Borrower> currentMembers) {
		this.currentMembers = currentMembers;
	}
	
	public String getMemberId() {
		return memberId;
	}


	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getMiddleName() {
		return middleName;
	}


	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getStreet() {
		return street;
	}


	public void setStreet(String street) {
		this.street = street;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public String getZipCode() {
		return zipCode;
	}


	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}


	public String getMobileNo() {
		return mobileNo;
	}


	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}


	public String getEmailId() {
		return emailId;
	}


	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}


	public String getCreatedDate() {
		return createdDate;
	}


	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}


	public String getModifiedDate() {
		return modifiedDate;
	}


	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}


	@Override
	public String toString() {
		return "Member [memberId=" + memberId + ", firstName=" + firstName + ", middleName=" + middleName
				+ ", lastName=" + lastName + ", address=" + address + ", street=" + street + ", city=" + city
				+ ", state=" + state + ", zipCode=" + zipCode + ", mobileNo=" + mobileNo + ", emailId=" + emailId
				+ ", createdDate=" + createdDate + ", modifiedDate=" + modifiedDate + "]";
	}
	
	
	public Member(String memberId, String firstName, String middleName, String lastName, String address, String street,
			String city, String state, String zipCode, String mobileNo, String emailId, String createdDate,
			String modifiedDate) {
		super();
		this.memberId = memberId;
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.address = address;
		this.street = street;
		this.city = city;
		this.state = state;
		this.zipCode = zipCode;
		this.mobileNo = mobileNo;
		this.emailId = emailId;
		this.createdDate = createdDate;
		this.modifiedDate = modifiedDate;
	}

	public Member() {
		super();
	}	

}
