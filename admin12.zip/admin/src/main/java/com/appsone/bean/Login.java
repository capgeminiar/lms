package com.appsone.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "LOGIN")
public class Login {

	@Id
   	@Column(name = "USERNAME")
	private String userName;
	
	@Column(name = "PASSWORD")
	private String password;
	
	@Column(name = "ROLEID")
	private int roleId;
	
	@Column(name = "PASS_EXP")
	private int pass_exp_days;
	
	@Column(name = "CREATEDDATE")
	private String createdDate;
	
	@Column(name = "MODIFIEDDATE")
	private String modifiedDate;
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getRoleId() {
		return roleId;
	}
	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}
	public int getPass_exp_days() {
		return pass_exp_days;
	}
	public void setPass_exp_days(int pass_exp_days) {
		this.pass_exp_days = pass_exp_days;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	
	@Override
	public String toString() {
		return "Login [userName=" + userName + ", password=" + password + ", roleId=" + roleId + ", pass_exp_days="
				+ pass_exp_days + ", createdDate=" + createdDate + ", modifiedDate=" + modifiedDate + "]";
	}
	
	public Login(String userName, String password, int roleId, int pass_exp_days, String createdDate,
			String modifiedDate) {
		super();
		this.userName = userName;
		this.password = password;
		this.roleId = roleId;
		this.pass_exp_days = pass_exp_days;
		this.createdDate = createdDate;
		this.modifiedDate = modifiedDate;
	}
	
	public Login() {
		super();
	}
}
