package com.appsone.bean;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.springframework.stereotype.Component;

@Component("CustomClock")
public class CustomClock {

	    Calendar calendar = new GregorianCalendar();
	    
	    public CustomClock() {
	    	calendar = Calendar.getInstance();
	    }
	    
	    public Calendar getCalendar() {
			return calendar;
		}

		public void setCalendar(String dateStr) throws ParseException {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy/M/dd hh:mm");
			Date date = sdf.parse(dateStr);
	        calendar.setTime(date);
		}
		
		public void resetCalendar() {
	        calendar = Calendar.getInstance();
	    }	
}
