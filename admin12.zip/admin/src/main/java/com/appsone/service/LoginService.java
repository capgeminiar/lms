package com.appsone.service;

import com.appsone.bean.Login;

public interface LoginService {

	Login validateUser(Login login);

}