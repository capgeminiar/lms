package com.appsone.service;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.appsone.bean.Book;
import com.appsone.bean.Booksforapproval;
import com.appsone.bean.Member;
import com.appsone.bean.Status;
import com.appsone.dao.LibrarianDao;
import com.appsone.time.ClockService;

@Service("librarianService")
@Transactional
public class LibrarianServiceImpl implements LibrarianService {
	
	@Autowired
	LibrarianDao librarianDAO;
	
	@Autowired
    private ClockService clockService;

	
   // Member functionalities
	@Override
	public List<Member> findAllMembers() {
		return librarianDAO.findAllMembers();
	}

	@Override
	public Member getMember(String memberId) {
		return librarianDAO.getMember(memberId);
	}

	@Override
	public void updateMember(Member member) {
		librarianDAO.updateMember(member);
	}

	@Override
	public boolean removeMember(String memberId) {
		return librarianDAO.removeMember(memberId);
	}

	@Override
	public Member createMember(Member member) {
		return librarianDAO.createMember(member);
	}

	// Book Functionalities
	@Override
	public boolean addBook(Book book) {
		return librarianDAO.addBook(book);
	}

	@Override
	public List<Book> findAllBooks() {
		return librarianDAO.findAllBooks();
	}

	@Override
	public Book getBookById(int bookId) {
		return librarianDAO.getBookById(bookId);
	}

	@Override
	public boolean removeBookByID(int bookId) {
		return librarianDAO.removeBookByID(bookId);
	}

	@Override
	public void updateBook(Book updatedBook) {
		librarianDAO.updateBook(updatedBook);
	}

	@Override
	public String findCountAvailable() {
		return librarianDAO.findCountAvailable();
	}

	@Override
	public boolean changePassword(String password, String username) {
	
		return librarianDAO.changePassword(password, username);
	}

	@Override
	public ArrayList<Status> getAllMembersStatus() {
		
		return librarianDAO.getAllMembersStatus();
	}

	@Override
	public String createExcel() {
		
		ArrayList<Status> statusList=librarianDAO.getAllMembersStatus();
		
		
		String file=null;
	        if(statusList != null && !statusList.isEmpty()){
	            HSSFWorkbook workBook = new HSSFWorkbook();
	            HSSFSheet sheet = workBook.createSheet();
	            sheet.setDefaultColumnWidth(25);
	            
	            // create style for header cells
	            HSSFCellStyle style = workBook.createCellStyle();
	            style.setFillForegroundColor(HSSFColor.HSSFColorPredefined.BLUE.getIndex());
	            style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
	            
	            HSSFFont font = workBook.createFont();
	            font.setColor(HSSFColor.HSSFColorPredefined.WHITE.getIndex());
	            style.setFont(font);
	            
	            
	            CellStyle cellStyle = workBook.createCellStyle();
	    		CreationHelper createHelper = workBook.getCreationHelper();
	    		cellStyle.setDataFormat(createHelper.createDataFormat().getFormat("DD-MM-YYYY"));
	    		
	    		Calendar cal = clockService.getcalendar();
	    		HSSFRow head = sheet.createRow(0);
	    		head.createCell(2).setCellValue(cal.getTime());
	    		head.getCell(2).setCellStyle(cellStyle);
	    		
	    		HSSFRow header = sheet.createRow(2);
	    		
	    		header.createCell(0).setCellValue("STATUSID");
	    		header.getCell(0).setCellStyle(style);
	    		
	  	      	header.createCell(1).setCellValue("MEMBERID");
	  	      	header.getCell(1).setCellStyle(style);
	  	      	
	  	      	header.createCell(2).setCellValue("PRICE_OF_MBRSHIP");
	  	      	header.getCell(2).setCellStyle(style);
	  	      	
	  	      	header.createCell(3).setCellValue("VALIDITY");
	  	      	header.getCell(3).setCellStyle(style);
	  	      	
	  	      	header.createCell(4).setCellValue("MBRSHIP_START_DATE");
	  	      	header.getCell(4).setCellStyle(style);
	  	      	
	  	      	header.createCell(5).setCellValue("MBRSHIP_END_DATE");
	  	      	header.getCell(5).setCellStyle(style);
	  	      
	  	        // create data rows
	  	        int rowCount = 3;
	  	         
	  	        for (Status astatus : statusList) {

	  	        	//create the row data
	  	        	HSSFRow aRow = sheet.createRow(rowCount++);
	  	            aRow.createCell(0).setCellValue(astatus.getStatusId());
	  	            aRow.createCell(1).setCellValue(astatus.getMemberId());
	  	            aRow.createCell(2).setCellValue(astatus.getPrice());
	  	            aRow.createCell(3).setCellValue(astatus.getValidity());
	  	       
	  	          // aRow.createCell(4).setCellValue(astatus.getStartDate());
	  	          // aRow.setRowStyle(cellStyle);
	  		    
	  	            Cell cell = aRow.createCell(4);
	  	            cell.setCellValue(astatus.getStartDate());
	  	            cell.setCellStyle(cellStyle);
	  	         
	  	            Cell cell2 = aRow.createCell(5);
	  	            cell2.setCellValue(astatus.getEndDate());
	  	            cell2.setCellStyle(cellStyle);
	  	            
	  	            //aRow.createCell(5).setCellValue(astatus.getEndDate());
	  	            //aRow.createCell(5).setCellStyle(cellStyle);
	  	            System.err.println(astatus.getStartDate());
	  	            System.err.println(astatus.getEndDate());
	  	        }
	            
	             file = "C:/Users/"+System.getProperty("user.name")+"/Downloads/Status.xls";
	            try{
	                FileOutputStream fos = new FileOutputStream(file);
	                workBook.write(fos);
	                fos.flush();
	            }catch(FileNotFoundException e){
	                e.printStackTrace();
	                System.out.println("Invalid directory or file not found");
	                return "Invalid directory or file not found";
	    
	            }catch(IOException e){
	                e.printStackTrace();
	                System.out.println("Error occurred while writting excel file to directory");
	            }
	        }
	        
		return file;	
	}

	@Override
	public List<Booksforapproval> findAllBooksforApproval() {
		
		return librarianDAO.findAllBooksforApproval();
	}

	@Override
	public String approveBook(int bookId, String memberId, String librarianId) throws ParseException {
		
		return librarianDAO.approveBook(bookId, memberId, librarianId);
	}	
	
	
	
}
