package com.appsone.service;

import java.text.ParseException;
import java.util.List;

import com.appsone.bean.Booksforapproval;
import com.appsone.bean.Borrower;
import com.appsone.bean.Status;

public interface MemberService {

	String setBookRequest(int bookId, String memberId) throws ParseException;

	void updateBookStatus(int bookId);
	
	String setBookReturn(int bookId, String memberId);
	
	List<Borrower> myBorrowings(String memberId);
	
	List<Booksforapproval> myRequestings(String memberId);
	
	List<Borrower> circulationBooks();
	
	// Status
	Status addStatus(Status status);
		
	Status editStatus(Status status);
		
	Status getStatusById(String memberId);
	
	Status viewStatus(String memberId);

}