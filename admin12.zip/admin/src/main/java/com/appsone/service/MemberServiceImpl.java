package com.appsone.service;

import java.text.ParseException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.appsone.bean.Booksforapproval;
import com.appsone.bean.Borrower;
import com.appsone.bean.Status;
import com.appsone.dao.MemberDao;

@Transactional
@Service("memberService")
public class MemberServiceImpl implements MemberService {

	@Autowired
	MemberDao memberDAO;
	
	@Override
	public String setBookRequest(int bookId, String memberId) throws ParseException {
		return memberDAO.setBookRequest(bookId, memberId);
	}
	
	@Override
	public void updateBookStatus(int bookId) {
		memberDAO.updateBookStatus(bookId);
	}

	@Override
	public String setBookReturn(int bookId, String memberId) {
		
		return memberDAO.setBookReturn(bookId, memberId);
	}

	@Override
	public List<Borrower> myBorrowings(String memberId) {
		
		return memberDAO.myBorrowings(memberId);
	}

	@Override
	public List<Borrower> circulationBooks() {
		
		return memberDAO.circulationBooks();
	}

	@Override
	public Status addStatus(Status status) {
		
		return memberDAO.addStatus(status);
	}

	@Override
	public Status editStatus(Status status) {
		
		return memberDAO.editStatus(status);
	}

	@Override
	public Status getStatusById(String memberId) {
		
		return memberDAO.getStatusById(memberId);
	}

	@Override
	public Status viewStatus(String memberId) {
		
		return memberDAO.viewStatus(memberId);
	}

	@Override
	public List<Booksforapproval> myRequestings(String memberId) {
		
		return memberDAO.myRequestings(memberId);
	}
}
