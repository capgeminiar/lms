package com.appsone.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.appsone.bean.Login;
import com.appsone.dao.LoginDao;

@Service("loginService")
public class LoginServiceImpl implements LoginService {

	@Autowired
	LoginDao loginDao;

	public Login validateUser(Login login) {
		// TODO Auto-generated method stub
		return loginDao.validateUser(login);
	}
	
	
	
}
