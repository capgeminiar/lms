package com.appsone.time;

import java.text.ParseException;
import java.util.Calendar;

import org.springframework.stereotype.Component;

@Component("ClockService")
public interface ClockService {

	Calendar getcalendar();

	void setCalendar(String dateStr) throws ParseException;

	void resetCalendar();

	void displayCurrentTime();

}