package com.appsone.time;

import java.text.ParseException;
import java.util.Calendar;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.appsone.bean.CustomClock;

@Service
public class ClockServiceImpl implements ClockService {
	
	@Autowired
	CustomClock customClock;
	
	@Override
	public Calendar getcalendar() {
		return customClock.getCalendar();
	}
	
	 @Override
	public void setCalendar(String dateStr) throws ParseException {
	        customClock.setCalendar(dateStr);
	    }
	 
	 @Override
	public void resetCalendar() {
	        customClock.resetCalendar();
	    }
	 
	 @Override
	public void displayCurrentTime() {
	        System.out.println("The set time for LMS is: " + customClock.getCalendar().getTime());
	    }
}
