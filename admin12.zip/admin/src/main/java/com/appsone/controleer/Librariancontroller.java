package com.appsone.controleer;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.appsone.bean.Book;
import com.appsone.bean.Booksforapproval;
import com.appsone.bean.Login;
import com.appsone.bean.Member;
import com.appsone.bean.Status;
import com.appsone.service.LibrarianService;
import com.appsone.service.LoginService;
import com.appsone.service.MemberService;

@Controller
public class Librariancontroller {
	public Librariancontroller() {
		System.err.println("In controller");
	}
	
	@Autowired
	LoginService loginService;
	
	@Autowired
	LibrarianService librarianService; 
	
	@Autowired
	MemberService memberService;
	
	@RequestMapping(value = "/")
	  public String home(HttpServletRequest request, HttpServletResponse response) {
	   
	    return "home";
	  }

	/* List all members */
	@RequestMapping(value="/listdetails")
	public ModelAndView listAllMembers(Model model) {
		
		model.addAttribute("member", new Member());
		model.addAttribute("memberList",librarianService.findAllMembers());

		return new ModelAndView("listAllMembers");
	}

	@RequestMapping(value="/addMember")
	public ModelAndView addMember(@ModelAttribute("member") Member member)
				throws IOException {
		
			return new ModelAndView("addMember");

		}

		@RequestMapping(value="/addNewMember", method= RequestMethod.POST)
		public void addNewMember(HttpServletResponse response,
				HttpSession session, @ModelAttribute("member") Member member,
				BindingResult result, Model model
				) throws IOException, ServletException  {
			System.out.println("model daata is-------------------------------------"+ member);
			
			try {
			
				librarianService.createMember(member);
				System.out.println("member created");
			} catch (Exception e) {
				
				System.err.println("In catch block");
				System.out.println("Exception is ---------"+e);
			}
			response.sendRedirect("listdetails");
		}
		
		/* List all members for edit */
		@RequestMapping(value="/editMembers")
		public ModelAndView editAllMembers(Model model) {
			
			model.addAttribute("member", new Member());
			model.addAttribute("memberList",librarianService.findAllMembers());

			return new ModelAndView("editMembers");
		}
		
		/* edit a member */
		@RequestMapping(value="/edit/{id}")
		public ModelAndView editMember(@PathVariable("id") String memberId,
				Model model) {
			model.addAttribute("member", new Member());
			model.addAttribute("memberList", librarianService.findAllMembers());
			System.out.println("data of editing= ........................"+memberId);
			Member mem=librarianService.getMember(memberId);
			return new ModelAndView("editMemberById", "mem", mem );
					
		}
		
		@RequestMapping(value="/updateMemberDetails")
		public void updateMember(@ModelAttribute("member") Member member,
				HttpServletResponse response)
				throws IOException {
			System.out.println("data of edit-----------------------------= "+member);
			
			librarianService.updateMember(member);
			
			response.sendRedirect("listdetails");
		}
		
		/* List all members for removal */
		@RequestMapping(value="/removeMembers")
		public ModelAndView removeAllMembers(Model model) {
			
			model.addAttribute("member", new Member());
			model.addAttribute("memberList",librarianService.findAllMembers());

			return new ModelAndView("removeMembers");
		}
		
		/* removing a member */
		@RequestMapping("/remove/{id}")
		public ModelAndView removeMember(@PathVariable("id") String memberId,Model model,
				HttpServletResponse response) throws IOException {
			
			/*model.addAttribute("member", new Member());
			model.addAttribute("mem", librarianService.getMember(memberId));*/
			/*Member mem=librarianService.getMember(memberId);*/
			try {
				System.out.println("memberId for removal is----------"+memberId);
				librarianService.removeMember(memberId);
				System.out.println("member is removed");
			} catch (Exception e) {
				System.err.println("In catch block");
				System.out.println("Exception is ---------"+e);
			}
			/*return new ModelAndView("removeMemberById", "mem", mem);*/	
			/*response.sendRedirect("listdetails");*/
			return new ModelAndView("redirect:/listdetails");
		}
		
		/*@RequestMapping(value="/removeMemberDetails")
		public void deleteEmployee(@ModelAttribute("member") Member member,
				HttpServletResponse response)
				throws IOException {
			System.out.println("data of edit-----------------------------= "+member);
			
			response.sendRedirect("listdetails");
		}*/
		
		/* List all books */
		@RequestMapping(value="/listbookdetails")
		public ModelAndView listAllBooks(Model model) {
			
			model.addAttribute("book", new Book());
			model.addAttribute("bookList",librarianService.findAllBooks());

			return new ModelAndView("listAllBooks");
		}

		@RequestMapping(value="/addBook")
		public ModelAndView addBook(@ModelAttribute("book") Book book)
					throws IOException {
			
				return new ModelAndView("addBook");

			}

			@RequestMapping(value="/addNewBook", method= RequestMethod.POST)
			public void addNewBook(HttpServletResponse response,
					HttpSession session, @ModelAttribute("book") Book book,
					BindingResult result, Model model
					) throws IOException, ServletException  {
				System.out.println("model daata is-------------------------------------"+ book);
				
				try {
				
					librarianService.addBook(book);
					System.out.println("book added");
				} catch (Exception e) {
					
					System.err.println("In catch block");
					System.out.println("Exception is ---------"+e);
				}
				response.sendRedirect("listbookdetails");
			}

			
			/* List all books for edit */
			@RequestMapping(value="/editBooks")
			public ModelAndView editAllBooks(Model model) {
				
				model.addAttribute("book", new Book());
				model.addAttribute("bookList",librarianService.findAllBooks());

				return new ModelAndView("editBooks");
			}
			
			/* edit a book */
			@RequestMapping(value="/editNo/{no}")
			public ModelAndView editBook(@PathVariable("no") int bookId,
					Model model) {
				model.addAttribute("book", new Book());
				model.addAttribute("bookList", librarianService.findAllBooks());
				System.out.println("data of editing= ........................"+bookId);
				Book bk=librarianService.getBookById(bookId);
				return new ModelAndView("editBookById", "bk", bk );
						
			}
			
			@RequestMapping(value="/updateBookDetails")
			public void updateBook(@ModelAttribute("book") Book book,
					HttpServletResponse response)
					throws IOException {
				System.out.println("data of edit-----------------------------= "+book);
				
				librarianService.updateBook(book);
				
				response.sendRedirect("listbookdetails");
			}
			
			/* List all books for removal */
			@RequestMapping(value="/removeBooks")
			public ModelAndView removeAllBooks(Model model) {
				
				model.addAttribute("book", new Book());
				model.addAttribute("bookList",librarianService.findAllBooks());

				return new ModelAndView("removeBooks");
			}
			
			/* removing a book */
			@RequestMapping("/removeNo/{no}")
			public ModelAndView removeBook(@PathVariable("no") int bookId,Model model,
					HttpServletResponse response) throws IOException {
				
				try {
					System.out.println("bookId for removal is----------"+bookId);
					librarianService.removeBookByID(bookId);
					System.out.println("book is removed");
				} catch (Exception e) {
					System.err.println("In catch block");
					System.out.println("Exception is ---------"+e);
				}
				return new ModelAndView("redirect:/listbookdetails");
			}
			
			/* Change Password*/
			@RequestMapping(value="/changePasswd", method=RequestMethod.GET)
			public ModelAndView ChangePassword() {
				ModelAndView mav = new ModelAndView("ChangePasswd");
			    mav.addObject("changePasword", new Login());
			    return mav;
				//return new ModelAndView("ChangePassword");
			}
			
			@RequestMapping(value="/afterChangePassword", method=RequestMethod.POST)
			public ModelAndView afterChangePassword(Model model, @ModelAttribute("changePasword") Login changePasword, /*@RequestParam("previouspassword") String previouspassword,*/ @RequestParam("password") String password,
														HttpServletRequest request,HttpServletResponse response, HttpSession httpSession, String username)
			{
				
				httpSession = request.getSession(false); 
				//False because we do not want it to create a new session if it does not exist.
				if(httpSession != null){
					username = (String) httpSession.getAttribute("username");
				}
				
				
				System.out.println("user name is----@@"+ username);
				System.out.println("inside changing password.");
				System.out.println("new password:"+ password);
				boolean bool1=librarianService.changePassword(password, username);
				if(bool1==true)
				{
					model.addAttribute("successchange","YOUR PASSWORD IS SUCCESSFULLY CHANGED.");	
		         }
				else
				{
					model.addAttribute("failurechange","YOUR PASSWORD IS NOT CHANGED.");
				}
				return new ModelAndView("ChangePasswd");
			}
			
			@RequestMapping(value="/addAllStatus")
			public ModelAndView addAllMembersStatus(Model model) {
				
				model.addAttribute("member", new Member());
				model.addAttribute("memberList", librarianService.findAllMembers());
				return new ModelAndView("listAllMembersforAddStatus");		
			}
			
			@RequestMapping(value="/addStat/{no}")
			public ModelAndView AddMemberStatusById(@PathVariable("no") String memberId,
					Model model) {
				
				System.err.println("MemberId for adding Status = ........................" + memberId);
				try {
				        memberService.getStatusById(memberId);
				} catch(Exception e) {
					//add here
					model.addAttribute("status", new Status());
					model.addAttribute("memberId", memberId);
					return new ModelAndView("addStatusById");
				}
				return new ModelAndView("Failure", "msg", "This Member already have status !!!!!");
						
			}
			
			@RequestMapping(value="/addStatById", method=RequestMethod.POST)
			public ModelAndView AddMemberStatus(HttpServletResponse response, Model model2, 
					@ModelAttribute("status") Status status, BindingResult result) throws IOException {
						
				if(status.getPrice() == 0) {
					 
					return new ModelAndView("Failure", "msg", "Please select a plan !!!!!");
				} else {
					
					try {
						 memberService.getStatusById(status.getMemberId());
						
					} catch (Exception e) {
					
						try {
								Status status2 = memberService.addStatus(status);
								System.err.println("status added----" + status2);
								model2.addAttribute("successmsg", "Status for member is added...");
							
						} catch (Exception a) {
				 
							System.out.println("Exception is:" + a);
							model2.addAttribute("failuremsg", "Status for member is not added...");
						}
						return new ModelAndView("redirect:/viewAllStatus");
					}
					return new ModelAndView("Failure", "msg", "This Member already have status !!!!!");
				}
			}
			
			
			@RequestMapping(value="/viewAllStatus")
			public ModelAndView viewAllMembersStatus(Model model) {
				
				try {
				      List<Status> statusList = librarianService.getAllMembersStatus();
				      model.addAttribute("status", new Status());
				      model.addAttribute("statusList", statusList);
				      return new ModelAndView("listAllStatus");
				      
				} catch (Exception e) {
					
					return new ModelAndView("Failure", "msg", "No Member has taken any Plan or There is no Status to see for any Member !!!!!");
				}	
			}
			
			
			
			@RequestMapping(value="/editAllStatus")
			public ModelAndView editAllMembersStatus(Model model) {
				
				model.addAttribute("member", new Member());
				model.addAttribute("memberList", librarianService.findAllMembers());
				return new ModelAndView("listAllMembersforEditStatus");		
			}
			
			@RequestMapping(value="/editStat/{no}")
			public ModelAndView EditMemberStatusById(@PathVariable("no") String memberId,
					Model model) {
				
				System.err.println("MemberId for editing Status = ........................" + memberId);
				
				try {
					
					Status sta = memberService.getStatusById(memberId);
					model.addAttribute("status", new Status());
					model.addAttribute("sta", sta );
					return new ModelAndView("editStatusById");
					
				} catch (Exception e) {
					
					return new ModelAndView("Failure", "msg", "This Member don't have Status to Edit or not taken Membership in the Library !!!!!");
				}
			}
			
			@InitBinder
		    public void initBinder(WebDataBinder binder) {
		        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		        sdf.setLenient(true);
		        binder.registerCustomEditor(Date.class, new CustomDateEditor(sdf, true));
		    }
			
			@RequestMapping(value="/updateStatById", method=RequestMethod.POST)
			public ModelAndView updateMemberStatus(HttpServletResponse response, Model model2, 
					@ModelAttribute("sta") Status status, BindingResult result) throws IOException {
				
				if(status.getPrice() == 0) {
					 
					return new ModelAndView("Failure", "msg", "Please select a plan !!!!!");
				}
				else {
				try {
						System.err.println(status);
						Status status2 = memberService.editStatus(status);
						System.err.println("updated status is---" + status2);
						model2.addAttribute("successmsg", "Status for member is updated...");
						
				} catch(Exception e) {
					
					System.err.println("Exception is----" + e);
					model2.addAttribute("failuremsg", "Status for member is not updated...");
				}
				return new ModelAndView("redirect:/viewAllStatus");
				}
			}

			
			@RequestMapping(value="/approveBooks")
			public ModelAndView approveBooksforMembers(Model model) {
				
				model.addAttribute("booksforapproval", new Booksforapproval());
				model.addAttribute("booksforapprovalList", librarianService.findAllBooksforApproval());
				return new ModelAndView("listAllbooksforapproval");		
			}
			
			@RequestMapping(value="/approve/{id1}/mem/{id2}")
			public ModelAndView approveBooks(@PathVariable("id1") int bookId, @PathVariable("id2") String memberId, Model model, HttpServletResponse response,
					            HttpServletRequest request, HttpSession httpSession, String librarianId) {
				
				httpSession = request.getSession(false); 
				//False because we do not want it to create a new session if it does not exist.
				if(httpSession != null){
				    librarianId = (String) httpSession.getAttribute("username");
				}
				
				System.out.println("librarian id is----@@"+ librarianId);
			
				String s = null;
				try {
					 	s = librarianService.approveBook(bookId, memberId, librarianId);
					 	model.addAttribute("successmsg", "book is approved ...");
					 	
				} catch (ParseException e) {
				
					e.printStackTrace();
					model.addAttribute("failuremsg", "book is not approved ...");
				}
				System.err.println(s);
				return new ModelAndView("redirect:/approveBooks");
			}
			
			
			@ModelAttribute("priceList")
			   public List<Integer> getPriceList() {
			      List<Integer> priceList = new ArrayList<Integer>();
			      priceList.add(500);
			      priceList.add(1000);
			      return priceList;
			   }
}