package com.appsone.controleer;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.appsone.bean.Book;
import com.appsone.bean.Booksforapproval;
import com.appsone.bean.Borrower;
import com.appsone.bean.Status;
import com.appsone.service.LibrarianService;
import com.appsone.service.LoginService;
import com.appsone.service.MemberService;

@Controller
public class MemberController {
	
	@Autowired
	LoginService loginService;
	
	@Autowired
	MemberService memberService;
	
	@Autowired
	LibrarianService librarianService;
	
	@RequestMapping(value = "/")
	  public String home(HttpServletRequest request, HttpServletResponse response) {
	   
	    return "home";
	  }
	
	/*List all books for borrow*/
	@RequestMapping(value="/borrowBook")
	public ModelAndView listAllBooksForBorrrow(Model model) {
		
		model.addAttribute("book", new Book());
		model.addAttribute("bookList",librarianService.findAllBooks());

		return new ModelAndView("listAllBooksForBorrow");
	}

	/* book for borrow*/
	@RequestMapping(value="/borrow/{id}")
	public ModelAndView bookBorrrow(@PathVariable("id") int bookId, Model model, HttpServletResponse response,
			            HttpServletRequest request, HttpSession httpSession, String memberId) {
		
		httpSession = request.getSession(false); 
		//False because we do not want it to create a new session if it does not exist.
		if(httpSession != null){
		    memberId = (String) httpSession.getAttribute("username");
		}
		
		System.out.println("member id is----@@"+ memberId);
		//model.addAttribute("book", new Book());
		try {
			System.out.println("entered in try block====");
			String s=memberService.setBookRequest(bookId, memberId);
			System.out.println(s);
			/*if(s==null) {
				System.out.println("bookIsNotAvailable");
				//return new ModelAndView("bookIsNotAvailable");
			}*/
			model.addAttribute("bk",s);
			System.out.println("model data @@@@@@@@"+model);
		} catch (ParseException e) {
			System.out.println("entered in catch block======");
			e.printStackTrace();
		}
		return new ModelAndView("borrowedBooks");
		//return "borrowedBooks";
		
	}
	
	@RequestMapping(value="/currentBorrowings")
	public ModelAndView viewMyCurrentBorrowings(Model model, HttpServletResponse response,
            HttpServletRequest request, HttpSession httpSession, String memberId) {
		
		
		httpSession = request.getSession(false); 
		//False because we do not want it to create a new session if it does not exist.
		if(httpSession != null){
		    memberId = (String) httpSession.getAttribute("username");
		}
		
		System.out.println("member id is----@@"+ memberId);
		
		
		model.addAttribute("borrower", new Borrower());
		model.addAttribute("borrowerList",memberService.myBorrowings(memberId));

		return new ModelAndView("MyCurrentBorrowings");		
	}
	
	@RequestMapping(value="/currentRequestings")
	public ModelAndView viewMyCurrentRequestings(Model model, HttpServletResponse response,
            HttpServletRequest request, HttpSession httpSession, String memberId) {
		
		
		httpSession = request.getSession(false); 
		//False because we do not want it to create a new session if it does not exist.
		if(httpSession != null){
		    memberId = (String) httpSession.getAttribute("username");
		}
		
		System.out.println("member id is----@@"+ memberId);
		
		
		model.addAttribute("booksforapproval", new Booksforapproval());
		model.addAttribute("booksforapprovalList", memberService.myRequestings(memberId));

		return new ModelAndView("MyCurrentRequestings");		
	}
	
	
	@RequestMapping(value="/returnBook")
	public ModelAndView returnBooks(Model model, HttpServletResponse response,
            HttpServletRequest request, HttpSession httpSession, String memberId) {
		
		
		httpSession = request.getSession(false); 
		//False because we do not want it to create a new session if it does not exist.
		if(httpSession != null){
		    memberId = (String) httpSession.getAttribute("username");
		}
		
		System.out.println("member id is----@@"+ memberId);
		
		
		model.addAttribute("borrower", new Borrower());
		model.addAttribute("borrowerList",memberService.myBorrowings(memberId));

		return new ModelAndView("returnBook");		
	}
	
	
	/* book for return*/
	@RequestMapping(value="/return/{id}")
	public ModelAndView returnBookbyId(@PathVariable("id") int bookId, Model model, HttpServletResponse response,
			            HttpServletRequest request, HttpSession httpSession, String memberId) {
		
		httpSession = request.getSession(false); 
		//False because we do not want it to create a new session if it does not exist.
		if(httpSession != null){
		    memberId = (String) httpSession.getAttribute("username");
		}
		
		System.out.println("member id is----@@"+ memberId);
		
		try {
			System.out.println("entered in try block====");
			String s=memberService.setBookReturn(bookId, memberId);
			System.out.println(s);
			model.addAttribute("bk",s);
			System.out.println("model data @@@@@@@@"+model);
		} catch (Exception e) {
			
			System.out.println("entered in catch block======");
			e.printStackTrace();
		}
		return new ModelAndView("returnedBook");	
	}

	
	/*List all books for borrow*/
	@RequestMapping(value="/circulationBooks")
	public ModelAndView circulatedBooks(Model model) {
		
		model.addAttribute("borrower", new Borrower());
		model.addAttribute("borrowerList", memberService.circulationBooks());

		return new ModelAndView("listAllBooksInCirculation");
	}
	
	
	// Status Part
	@RequestMapping(value="/addStatus")
	public ModelAndView addStatus(Model model) {
		
		Status status = new Status();
		model.addAttribute(status);
		return new ModelAndView("addStatus");
	}
	
	@RequestMapping(value="/addMyStatus", method=RequestMethod.POST)
	public ModelAndView addMyStatus(HttpServletResponse response, Model model, 
			@ModelAttribute("status") Status status, BindingResult result) throws IOException {
		
		if(status.getPrice() == 0) {
			 
			return new ModelAndView("Failure", "msg", "Please select a plan !!!!!");
		} else {
		
		try {
				 memberService.getStatusById(status.getMemberId());
				
		} catch (Exception e) {
			
			try {
					Status status2 = memberService.addStatus(status);
					System.err.println("status added----" + status2);
		       
			} catch (Exception a) {
			 
				System.out.println("Exception is:" + a);
			}
			return new ModelAndView("redirect:/viewMyStatus");
			//response.sendRedirect("viewMyStatus");
		}
		return new ModelAndView("Failure", "msg", "You already have a Plan, Please view your Status !!!!!");
		}
	}
	
	
	@RequestMapping(value="/viewMyStatus")
	public ModelAndView viewMyStatus(Model model, HttpServletResponse response,
            HttpServletRequest request, HttpSession httpSession, String memberId) {
		
		httpSession = request.getSession(false); 
		//False because we do not want it to create a new session if it does not exist.
		if(httpSession != null){
		    memberId = (String) httpSession.getAttribute("username");
		}
		
		System.out.println("member id is----@@"+ memberId);
		
		model.addAttribute("status", new Status());
		model.addAttribute("sta", memberService.viewStatus(memberId));
		return new ModelAndView("viewStatus");
	}
	
	@RequestMapping(value="/editMyStatus")
	public ModelAndView editMyStatus(Model model, HttpServletResponse response,
            HttpServletRequest request, HttpSession httpSession, String memberId) {
		
		httpSession = request.getSession(false); 
		//False because we do not want it to create a new session if it does not exist.
		if(httpSession != null){
		    memberId = (String) httpSession.getAttribute("username");
		}
		
		System.out.println("member id is----@@"+ memberId);
		
		try {
			
			Status sta = memberService.getStatusById(memberId);
			model.addAttribute("status", new Status());
			model.addAttribute("sta", sta );
			return new ModelAndView("editMyStatus");
			
		} catch (Exception e) {
			
			return new ModelAndView("Failure", "msg", "You don't have any Status to Edit or You have not taken Membership in the Library !!!!!");
		}
	}
	
	@InitBinder
    public void initBinder(WebDataBinder binder) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        sdf.setLenient(true);
        binder.registerCustomEditor(Date.class, new CustomDateEditor(sdf, true));
    }
	
	@RequestMapping(value="/updateMyStatus", method=RequestMethod.POST)
	public ModelAndView updateMyStatus(HttpServletResponse response, Model model, 
			@ModelAttribute("sta") Status status, BindingResult result) throws IOException {
		
		if(status.getPrice() == 0) {
			 
			return new ModelAndView("Failure", "msg", "Please select a plan !!!!!");
		}
		else {
		try {
			System.err.println(status);
				Status status2 = memberService.editStatus(status);
				System.err.println("updated status is---" + status2);
				
		} catch(Exception e) {
			
			System.err.println("Exception is----" + e);
		}
		return new ModelAndView("redirect:/viewMyStatus");
		//response.sendRedirect("viewMyStatus");
		}
	}
	
	@ModelAttribute("priceList")
	   public List<Integer> getPriceList() {
	      List<Integer> priceList = new ArrayList<Integer>();
	      priceList.add(500);
	      priceList.add(1000);
	      return priceList;
	   }
	
	@ModelAttribute("validityList")
	   public List<String> getValidityList() {
	      List<String> validityList = new ArrayList<String>();
	      validityList.add("6 Months");
	      validityList.add("1 Year");
	      return validityList;
	   }
	
}
