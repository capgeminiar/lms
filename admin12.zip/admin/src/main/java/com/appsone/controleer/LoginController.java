package com.appsone.controleer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.appsone.bean.Binding;
import com.appsone.bean.Book;
import com.appsone.bean.Booksforapproval;
import com.appsone.bean.Borrower;
import com.appsone.bean.Category;
import com.appsone.bean.CustomClock;
import com.appsone.bean.Login;
import com.appsone.bean.Member;
import com.appsone.bean.Role;
import com.appsone.bean.Status;
import com.appsone.service.LoginService;

@Controller
public class LoginController {
	
	@Autowired
	LoginService loginService;
	
	
	@RequestMapping(value = "/")
	  public String home(HttpServletRequest request, HttpServletResponse response) {
	   
	    return "home";
	  }
	
	
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	  public ModelAndView showLogin(HttpServletRequest request, HttpServletResponse response) {
	    ModelAndView mav = new ModelAndView("login");
	    mav.addObject("login", new Login());
	    return mav;
	  }
	
	  @RequestMapping(value = "/loginProcess", method = RequestMethod.POST)
	  public ModelAndView loginProcess(HttpServletRequest request, HttpServletResponse response,
			   @ModelAttribute("login") Login login) {
		  
		  ModelAndView mav = null;
		//data from login form
		  String username = request.getParameter("userName").trim();
		  String password = request.getParameter("password").trim();
		  Configuration configuration = new Configuration();
		  configuration.addAnnotatedClass(Login.class);
		  configuration.addAnnotatedClass(Binding.class);
		  configuration.addAnnotatedClass(Book.class);
		  configuration.addAnnotatedClass(Borrower.class);
		  configuration.addAnnotatedClass(Category.class);
		  configuration.addAnnotatedClass(CustomClock.class);  //check about this class because not annotated
		  configuration.addAnnotatedClass(Member.class);
		  configuration.addAnnotatedClass(Role.class);
		  configuration.addAnnotatedClass(Booksforapproval.class);
		  configuration.addAnnotatedClass(Status.class);
		  // need to add all entity classes
		  SessionFactory sessionFactory = configuration.configure().buildSessionFactory();
		  Session session = sessionFactory.openSession();  //check once whether you need to close these or not
		  session.beginTransaction();
		      Login user = (Login) session.get(Login.class, username);
		      System.out.println(user);
		      if(user == null) {
			    	
		    	  session.getTransaction().rollback();
					mav = new ModelAndView("login");
				    mav.addObject("message", "Username is wrong!!");
				    return mav;
				    
				}
		      if(password.equals(user.getPassword())) {
			    System.out.println(user.getRoleId()); 
			    
			    HttpSession httpSession = request.getSession();
			    httpSession.setAttribute("username", user.getUserName());  
			    //httpSession.setAttribute("user", user);
			    
			    int roleId=user.getRoleId();
				if(roleId==1)
				{
					mav = new ModelAndView("lib");
					
				}
				else /*if(roleId==2)*/
				{
					mav = new ModelAndView("mem");
					
				}
				mav.addObject("username", user.getUserName());
			    return mav;
		      }
		      
		      session.getTransaction().rollback();
				mav = new ModelAndView("login");
			    mav.addObject("message", "Password is wrong!!");
			    return mav; 
	  }
	  
	  @RequestMapping(value = "/logout")
	  public ModelAndView logout(Model model, HttpServletRequest request, HttpServletResponse response,
			  				HttpSession httpSession, String username) {
	   
		  httpSession = request.getSession(false); 
			//False because we do not want it to create a new session if it does not exist.
			if(httpSession != null){
				username = (String) httpSession.getAttribute("username");
			}
			
			System.out.println("username is :" + username);
			
			httpSession.removeAttribute("username");
			httpSession.invalidate();
			
			 ModelAndView mav = new ModelAndView("login");
			 mav.addObject("login", new Login());
			 mav.addObject("msg", "You are successfully logged out!");
			 return mav;
	  }

	  
	  @RequestMapping(value = "/librarian")
	  public ModelAndView homepage() {
		  
		return new ModelAndView("lib");
		}
	  
	  @RequestMapping(value = "/member")
	  public ModelAndView homepag() {
		  
		return new ModelAndView("mem");
		}
}
