package com.appsone.controleer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import com.appsone.service.LibrarianService;

@Controller
public class ExcelController extends AbstractController {

	@Autowired
	LibrarianService librarianService;
	
	
	  @RequestMapping(value = "/")
	  public String home(HttpServletRequest request, HttpServletResponse response) {
	   
	    return "home";
	  }
	
	@RequestMapping(value = "/downloadExcel")
	protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String name=librarianService.createExcel();
		String fail="Invalid directory or file not found";
		if(name!=fail)
		{
			ModelAndView model = new ModelAndView("Success");
			model.addObject("name",name);
			return model;
			
		}
		else
		{
			ModelAndView model = new ModelAndView("Failure");
			model.addObject("name",name);
			return model;
		}
		
	}

}
