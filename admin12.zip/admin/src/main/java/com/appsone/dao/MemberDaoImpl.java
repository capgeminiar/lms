package com.appsone.dao;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.appsone.bean.Book;
import com.appsone.bean.Booksforapproval;
import com.appsone.bean.Borrower;
import com.appsone.bean.Member;
import com.appsone.bean.Status;
import com.appsone.time.ClockService;

@Transactional
@Repository("memberDAO")
public class MemberDaoImpl implements MemberDao {
	
	private EntityManager entityManager;

	public EntityManager getEntityManager() {
		return entityManager;
	}

	@PersistenceContext
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	
	@Autowired
    private ClockService clockService;

	@Override
	public String setBookRequest(int bookId, String memberId) throws ParseException {
		
		Book book=entityManager.find(Book.class, bookId);
		Member member=entityManager.find(Member.class, memberId);
		
		
		if(book.getIsactive().equalsIgnoreCase("y")) {
			
		
				System.err.println(member.getMemberId());
				System.out.println(memberId);
		        String query = "from Borrower b where b.returnedDate is null and b.member.memberId = :member";// and b.member = " + member.getMemberId() ;/*+ " and b.bookTitle = " + book.getBookTitle() ;*/
		        System.err.println("before query execution");
		        List<Borrower> borrowedBooks = entityManager.createQuery(query, Borrower.class).setParameter("member", member.getMemberId()).getResultList();
		        System.err.println("after query execution");
		        System.err.println(borrowedBooks.size());
				if(borrowedBooks.size()>=2) {
					
					return "*********************You have borrowed 2 books, Please return any one of the book to borrow this book & You are allowed to take only two books**********************";
					
				} else {
					System.err.println("books are < than 2");
					//String borrowerQuery = "select b from Borrower b where b.bookTitle = " + book.getBookTitle() + " and b.issuedTo = " + memberId;
					try {
						
					//String borrowerQuery = "select b from Borrower b where b.bookTitle = " + book.getBookTitle() + " and b.member.memberId = " + member.getMemberId() + " and b.returnedDate is null";
					String borrowerQuery = "from Borrower b where b.bookTitle = ?1 and b.member.memberId = ?2 and b.returnedDate is null";
					//System.err.println(borrowerQuery);
					System.err.println("before query2 execution");
				    Borrower b = entityManager.createQuery(borrowerQuery, Borrower.class).setParameter(1, book.getBookTitle()).setParameter(2, member.getMemberId()).getSingleResult();
				    System.err.println("after query2 execution");
				    System.out.println(b);
			        if (b != null) {
			                System.out.println("******* You have already borrowed the same book *********");
			                return "********************You have already borrowed the same book, Please check your current borrowed book****************";
			          } 
					} catch(Exception e) {
						
						String query2 = "from Booksforapproval b where b.member2.memberId = :memberId"; // start from here
						List<Booksforapproval> requestedBooks = entityManager.createQuery(query2, Booksforapproval.class).setParameter("memberId", memberId).getResultList();
						
						if(borrowedBooks.size()==1 && requestedBooks.size()==0) {
							
							allowforRequest(book, member);
							
							String returnStatus = "Book Requesting Successful, You already have 1 book and you requested for this book, You are not allowed to take next book ....";
							returnStatus = returnStatus + book.printBookInfo();
							System.err.println(returnStatus);
							return returnStatus;
							
						} else if(borrowedBooks.size()==0 && requestedBooks.size()==0) {
							
							allowforRequest(book, member);
							
							String returnStatus = "Book Requesting Successful, You did not have any book and you requested for this book, You are allowed to take only one next book ....";
							returnStatus = returnStatus + book.printBookInfo();
							System.err.println(returnStatus);
							return returnStatus;
							
						} else if(borrowedBooks.size()==0 && requestedBooks.size()==1) {
							
							try {
								
								    String requestedQuery = "from Booksforapproval b where b.book2.bookTitle = ?1 and b.member2.memberId = ?2"; 
								    System.err.println("before requestedQuery execution");
								    Booksforapproval b = entityManager.createQuery(requestedQuery, Booksforapproval.class).setParameter(1, book.getBookTitle()).setParameter(2, memberId).getSingleResult();
								    System.err.println("after requestedQuery execution");
								    System.out.println(b);
							        if (b != null) {
							                System.out.println("******* You have already requested the same book *********");
							                return "********************You have already requested the same book, Please check your current requested book****************";
							          } 
							        
							} catch (Exception a) {
							
								allowforRequest(book, member); // need compare here
							
								String returnStatus = "Book Requesting Successful, You did not have any book, requested 1 book previously and you requested for this book, You are not allowed to take next book ....";
								returnStatus = returnStatus + book.printBookInfo();
								System.err.println(returnStatus);
								return returnStatus;
							}
						} else if(borrowedBooks.size()==0 && requestedBooks.size()==2) {
							
							String returnStatus = "You did not have any book, requested 2 books previously. So, This book is not issued to You ....";
							//returnStatus = returnStatus + book.printBookInfo();
							System.err.println(returnStatus);
							return returnStatus;
							
						} else {
							
							String returnStatus = "You already have 1 book and requested 1 book. So, You are not allowed to take this book ....";
							System.err.println(returnStatus);
							return returnStatus;
							
						}			       
			          }
				}	
				
		 } else {
            
            return "This book is not available in the library.\n Someone has borrowed.";
         }
		return "borrowing not successful";
	}
	
	public void allowforRequest(Book book, Member member) {
		
	     book.setIsactive("N");
	     entityManager.merge(book);
	     Calendar cal = clockService.getcalendar();
	     Booksforapproval bfa = new Booksforapproval(book, member, cal.getTime());
	     entityManager.persist(bfa);
	     bfa.BFAPersist(book, member);
	     System.out.println("after bfa persist -- total books size " + book.getPresentBooks().size() + "total members size " + member.getPresentMembers().size());
		
	}

	@Override
	public void updateBookStatus(int bookId) {
		 
		/*Book book = (Book)entityManager.find(Book.class, bookId);
        entityManager.createQuery("update Book b SET b.isactive='N' where b.bookid=?").setParameter(1,bookId).executeUpdate();
        entityManager.refresh(book);*/
        
        Book book = entityManager.find(Book.class, bookId);
        
        book.setIsactive("N");
        System.out.println("book status set to N @@@@@");
        
	}

	@Override
	public String setBookReturn(int bookId, String memberId) {
		
		System.out.println("setBookReturn: starts now");
        String returnMessage = "";
        try {
        	
        	Calendar cal = clockService.getcalendar();
            Book book = entityManager.find(Book.class, bookId);
            String borrowerQuery = "select b from Borrower b where b.book.bookId = '" + bookId + "' and b.member.memberId = '" + memberId + "' and b.returnedDate is null";
            Borrower borrower = entityManager.createQuery(borrowerQuery, Borrower.class).getSingleResult();
            System.out.println(borrower);
            Date today = cal.getTime();
            borrower.setReturnedDate(today);
            entityManager.merge(borrower);
           
            System.err.println("inserted date is"+today);
            System.err.println("date from borrower table is--"+borrower.getReturnedDate());
            
            book.setIsactive("Y");
            entityManager.merge(book);
           
            System.err.println("inserted status is ----- "+book.getIsactive());
     
            System.out.println("setBookReturn: Book borrowed date: " + borrower.getBorrowedOn());
            returnMessage = "Book returned successfully: " + book.printBookInfo();
            return returnMessage;
            
        } catch (Exception e) {
        	
            return "Some error occurred while returning book. Please try again after some time.";
        }
	}

	@Override
	public List<Borrower> myBorrowings(String memberId) {
		
		Member member=entityManager.find(Member.class, memberId);
		
		String query = "from Borrower b where b.returnedDate is null and b.member.memberId = :member";
		List<Borrower> borrowers = entityManager.createQuery(query, Borrower.class).setParameter("member", member.getMemberId()).getResultList();
		return borrowers;
	}

	@Override
	public List<Borrower> circulationBooks() {
		
		String query = "from Borrower b where b.returnedDate is null";
		List<Borrower> borrowers = entityManager.createQuery(query, Borrower.class).getResultList();
		return borrowers;
	}

	@Override
	public Status addStatus(Status status) {
		
		Calendar cal = clockService.getcalendar();
		Status status2 = new Status(status.getMemberId(), status.getPrice(), cal.getTime());
		entityManager.persist(status2);
		return status2;
	}

	@Override
	public Status editStatus(Status status) {
		System.err.println(status);
		Status status2 = new Status(status.getStatusId(), status.getMemberId(), status.getPrice(), status.getStartDate(), status.getEndDate());
		entityManager.merge(status2);
		return status2;
	}

	@Override
	public Status getStatusById(String memberId) {
		//Status status = entityManager.find(Status.class, memberId);
		String query = "from Status s where s.memberId = :memberId";
		Status status = entityManager.createQuery(query, Status.class).setParameter("memberId", memberId).getSingleResult();
		return status;
	}

	@Override
	public Status viewStatus(String memberId) {
		
		//Member member = entityManager.find(Member.class, memberId);
		String Query = "from Status s where s.memberId = :memberId";
		try {
			
		      Status status = entityManager.createQuery(Query, Status.class).setParameter("memberId", memberId).getSingleResult();
		      return status;
		      
		} catch(Exception e) {
			
			System.err.println("Exception is----" + e);
			return null;
		}
		
	}

	@Override
	public List<Booksforapproval> myRequestings(String memberId) {
		
		String query = "from Booksforapproval b where b.member2.memberId = :memberId";
		List<Booksforapproval> requesters = entityManager.createQuery(query, Booksforapproval.class).setParameter("memberId", memberId).getResultList();
		return requesters;
	}
	
	
	

}
