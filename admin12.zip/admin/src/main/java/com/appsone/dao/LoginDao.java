package com.appsone.dao;

import com.appsone.bean.Login;

public interface LoginDao {

	Login validateUser(Login login);

}