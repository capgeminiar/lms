package com.appsone.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.appsone.bean.Login;

@Repository("loginDao")
public class LoginDaoImpl implements LoginDao {

	 
	 @Autowired
	 JdbcTemplate jdbcTemplate;
	 
	/* @Override
	public Login validateUser(Login login) {
		    String sql = "select * from login where username='" + login.getUserName() + "' and password='" + login.getPassword()
		    + "'";
		    List<Login> users = jdbcTemplate.query(sql, new UserMapper());
		    return users.size() > 0 ? users.get(0) : null;
		    }
}*/

class UserMapper implements RowMapper<Login> {
	  public Login mapRow(ResultSet rs, int arg1) throws SQLException {
		  Login user = new Login();
	    user.setUserName(rs.getString("username"));
	    user.setPassword(rs.getString("password"));
	    user.setRoleId(rs.getInt("roleId"));
	    user.setPass_exp_days(rs.getInt("pass_exp"));
	    user.setCreatedDate(rs.getString("createdDate"));
	    user.setModifiedDate(rs.getString("modifiedDate"));
	    return user;
	  }
	}

	public Login validateUser(Login login) {
		 String sql = "select * from login where username='" + login.getUserName() + "' and password='" + login.getPassword()
		    + "'";
		    List<Login> users = jdbcTemplate.query(sql, new UserMapper());
		    return users.size() > 0 ? users.get(0) : null;
		    
	}
}


