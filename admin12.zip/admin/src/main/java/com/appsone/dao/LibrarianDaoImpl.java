package com.appsone.dao;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.appsone.bean.Book;
import com.appsone.bean.Booksforapproval;
import com.appsone.bean.Borrower;
import com.appsone.bean.Member;
import com.appsone.bean.Status;
import com.appsone.time.ClockService;

@Transactional
@Repository("librarianDAO")
public class LibrarianDaoImpl implements LibrarianDao {

	/*@PersistenceContext(type = PersistenceContextType.EXTENDED)*/
	private EntityManager em;
	
	public EntityManager getEm() {
		return em;
	}

	@PersistenceContext
	public void setEm(EntityManager em) {
		this.em = em;
	}
	
	@Autowired
    private ClockService clockService;
	
	// Member functionalities
	public Member createMember(Member uEntity) {
		em.persist(uEntity);
        return uEntity;
	}
	
	public List<Member> findAllMembers(){
		List<Member> members=em.createQuery("select m from Member m",Member.class).getResultList();
		return members;
	}
	
	public Member getMember(String memberId) {
		Member member = em.find(Member.class, memberId);
		return member;
	}
	
	public void updateMember(Member member) {
		em.merge(member);
	}
	
	public boolean removeMember(String memberId) {
		Member member=em.find(Member.class, memberId);
		if(member==null) {
			return false;
		}
		else {
			em.remove(member);
		    return true;
		}
	}

	// Book Functionalities
	@Override
	public boolean addBook(Book book) {
		em.persist(book);
		return true;
	}

	@Override
	public List<Book> findAllBooks() {
		List<Book> books = em.createQuery("select b from Book b", Book.class).getResultList();
		return books;
	}

	@Override
	public Book getBookById(int bookId) {
		return em.find(Book.class, bookId);
	}

	@Override
	public boolean removeBookByID(int bookId) {
		Book book = em.find(Book.class, bookId);
		em.remove(book);
		return true;
	}

	@Override
	public void updateBook(Book updatedBook) {
		em.merge(updatedBook);	
	}

	@Override
	public String findCountAvailable() {
		Query query = em.createQuery("select count(b.bookId) from Book b where b.current_status = status");
        query.setParameter("status", "available");
        System.out.println("********** Available books= " + query.getResultList().get(0).toString());
		return query.getResultList().get(0).toString();
	}

	@Override
	public boolean changePassword(String password, String username) {
		
		String changepassword = "update Login l set l.password = :password where l.userName = :username";
		Query query = em.createQuery(changepassword); 
		query.setParameter("password", password).setParameter("username", username);
		int result=query.executeUpdate();
		if(result>0)
		    return true;
		else
			return false;
	}

	@Override
	public ArrayList<Status> getAllMembersStatus() {
		
		String query = "from Status";
		ArrayList<Status> statusList = (ArrayList<Status>) em.createQuery(query, Status.class).getResultList();
		return statusList;
	}

	@Override
	public List<Booksforapproval> findAllBooksforApproval() {
		String query = "from Booksforapproval";
		List<Booksforapproval> booksforapprovalList = em.createQuery(query, Booksforapproval.class).getResultList();
		return booksforapprovalList;
	}

	@Override
	public String approveBook(int bookId, String memberId, String librarianId) throws ParseException {
		
		Book book=em.find(Book.class, bookId);
		Member member=em.find(Member.class, memberId);
		String query = "from Booksforapproval b where b.book2.bookId = :bookId";
		Booksforapproval booksforapproval = em.createQuery(query, Booksforapproval.class).setParameter("bookId", bookId).getSingleResult();
		
		String returnStatus = "";
   	 	Calendar cal = clockService.getcalendar();
		Borrower borrower = new Borrower(book, member, cal.getTime(), librarianId);
		  Date due_date =  borrower.getDueDate();
	  returnStatus = "Book approving Successful. \n The Due date is " + due_date + "\n";
         returnStatus = returnStatus + book.printBookInfo();
        // entityManager.merge(book);
         em.persist(borrower);
        // borrower.BorrowerPersist(book, member);
        // updateBookStatus(book.getBookId());
         em.remove(booksforapproval);
         System.out.println("after borrower persist -- total books size " + book.getCurrentBooks().size() + "total members size " + member.getCurrentMembers().size());
         System.out.println(returnStatus);
         return returnStatus;
	}
	
	
	
}
