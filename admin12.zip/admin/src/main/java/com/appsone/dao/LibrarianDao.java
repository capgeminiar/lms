package com.appsone.dao;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import com.appsone.bean.Book;
import com.appsone.bean.Booksforapproval;
import com.appsone.bean.Member;
import com.appsone.bean.Status;

public interface LibrarianDao {

	// Member functionalities
	Member createMember(Member uEntity);

	List<Member> findAllMembers();

	Member getMember(String memberId);

	void updateMember(Member member);

	boolean removeMember(String memberId);
	
	// Book functionalities
    boolean addBook(Book book);
	
	List<Book> findAllBooks();
	
	Book getBookById(int bookId);
	
	boolean removeBookByID(int bookId);
	
	void updateBook(Book updatedBook);
	
	List<Booksforapproval> findAllBooksforApproval();
	
	String approveBook(int bookId, String memberId, String librarianId) throws ParseException;
	
	String findCountAvailable();
	
	boolean changePassword(String password, String username);
	
	// Status 
	ArrayList<Status> getAllMembersStatus();
	
}